# Bugfix Requirements Document

## Introduction

本文档针对"AI随行记"项目中发现的8个关键BUG进行综合修复。这些BUG涵盖了安全性、用户体验、错误处理和数据持久化等多个方面，影响了应用的稳定性和可用性。

"AI随行记"是一个基于 uni-app 的 AI 旅游微网页生成应用，支持拍照、定位、AI生成游记文案，并可导出为微网页分享。修复这些BUG将显著提升应用的安全性、稳定性和用户体验。

## Bug Analysis

### Current Behavior (Defect)

#### 1. API Key 安全问题

1.1 WHEN 开发者在 backend/package.json 的 npm scripts 中配置 API Key THEN 系统将 API Key 硬编码在代码仓库中，造成严重安全泄露风险

1.2 WHEN 代码被提交到版本控制系统 THEN API Key 会被永久记录在 Git 历史中，即使后续删除也无法完全清除

#### 2. API Key 验证逻辑问题

1.3 WHEN 用户点击"生成游记"按钮且 API Key 未配置或格式不正确 THEN 系统直接跳转到设置页面而不是弹窗提示，用户体验差

#### 3. 图片处理超时问题

1.4 WHEN 网络较慢或图片文件较大时进行图片处理 THEN 系统在 20 秒后超时返回 null，导致图片处理失败

1.5 WHEN 图片处理超时 THEN 生成功能无法正常使用，用户无法完成游记生成

#### 4. 云函数错误处理缺失

1.6 WHEN AI API 返回格式异常或缺少 choices 字段 THEN 云函数直接访问 `res.data.choices[0].message.content` 导致崩溃

1.7 WHEN 云函数崩溃 THEN 用户收到不明确的错误信息，无法判断问题原因

#### 5. 测试连接参数不完整

1.8 WHEN 用户在设置页面点击"测试连接"按钮 THEN 系统调用云函数时缺少必需的 address 参数，导致测试失败

1.9 WHEN 测试连接失败 THEN 用户无法验证 API Key 配置是否正确

#### 6. 图片压缩失败兜底逻辑问题

1.10 WHEN 微信小程序中图片压缩失败 THEN 系统直接读取原图并转换为 Base64，可能导致数据过大超出请求限制

1.11 WHEN Base64 数据超出限制 THEN API 请求失败，用户无法生成游记

#### 7. 历史记录图片路径失效

1.12 WHEN 用户生成游记后保存到历史记录 THEN 系统使用微信临时路径存储图片

1.13 WHEN 用户关闭小程序后重新打开 THEN 历史记录中的图片路径失效，无法显示

#### 8. 超时处理逻辑冲突

1.14 WHEN 用户触发生成游记或按建议重生成 THEN 系统同时使用 currentTimer 和 fallbackTimer 两个定时器

1.15 WHEN 两个定时器同时存在 THEN 超时处理逻辑混乱，可能导致重复触发或遗漏清理

### Expected Behavior (Correct)

#### 1. API Key 安全问题

2.1 WHEN 开发者需要配置 API Key THEN 系统 SHALL 使用环境变量或 .env 文件存储敏感信息，并将 .env 文件添加到 .gitignore

2.2 WHEN 代码被提交到版本控制系统 THEN API Key SHALL NOT 出现在任何提交记录中

#### 2. API Key 验证逻辑问题

2.3 WHEN 用户点击"生成游记"按钮且 API Key 未配置或格式不正确 THEN 系统 SHALL 弹出模态对话框提示用户，并提供"去设置"和"取消"选项

#### 3. 图片处理超时问题

2.4 WHEN 网络较慢或图片文件较大时进行图片处理 THEN 系统 SHALL 将超时时间延长至 60 秒或更长

2.5 WHEN 图片处理超时 THEN 系统 SHALL 记录警告日志并继续处理其他图片，不影响整体生成流程

#### 4. 云函数错误处理缺失

2.6 WHEN AI API 返回数据 THEN 云函数 SHALL 先检查 res.data、res.data.choices、res.data.choices[0] 等字段是否存在

2.7 WHEN API 返回格式异常 THEN 云函数 SHALL 返回明确的错误信息，包含错误类型和详细描述

#### 5. 测试连接参数不完整

2.8 WHEN 用户在设置页面点击"测试连接"按钮 THEN 系统 SHALL 传递完整的参数（包括 address、apiKey、model、baseUrl）给云函数

2.9 WHEN 测试连接成功 THEN 系统 SHALL 显示"云端就绪"提示，确认配置正确

#### 6. 图片压缩失败兜底逻辑问题

2.10 WHEN 微信小程序中图片压缩失败 THEN 系统 SHALL 先尝试降低质量参数重新压缩，如仍失败则跳过该图片

2.11 WHEN 跳过图片 THEN 系统 SHALL 记录警告并继续处理，不阻塞整体流程

#### 7. 历史记录图片路径失效

2.12 WHEN 用户生成游记后保存到历史记录 THEN 系统 SHALL 将图片上传到云存储或使用持久化本地路径

2.13 WHEN 用户重新打开小程序查看历史记录 THEN 图片 SHALL 正常显示，不受临时路径失效影响

#### 8. 超时处理逻辑冲突

2.14 WHEN 用户触发生成游记或按建议重生成 THEN 系统 SHALL 统一使用单一定时器管理超时逻辑

2.15 WHEN 请求完成或取消 THEN 系统 SHALL 确保定时器被正确清理，避免内存泄漏

### Unchanged Behavior (Regression Prevention)

#### 1. API Key 安全问题

3.1 WHEN 开发者使用 npm scripts 启动后端服务 THEN 系统 SHALL CONTINUE TO 正常启动并提供代理服务

#### 2. API Key 验证逻辑问题

3.2 WHEN 用户已正确配置 API Key 并点击"生成游记"按钮 THEN 系统 SHALL CONTINUE TO 直接调用 AI API 生成游记

#### 3. 图片处理超时问题

3.3 WHEN 网络正常且图片大小适中 THEN 系统 SHALL CONTINUE TO 在合理时间内完成图片处理

3.4 WHEN 图片处理成功 THEN 系统 SHALL CONTINUE TO 返回正确的 Base64 格式图片数据

#### 4. 云函数错误处理缺失

3.5 WHEN AI API 返回正常格式的数据 THEN 云函数 SHALL CONTINUE TO 正确提取并返回生成的内容

#### 5. 测试连接参数不完整

3.6 WHEN 用户保存 API Key 配置 THEN 系统 SHALL CONTINUE TO 正确存储到本地存储

#### 6. 图片压缩失败兜底逻辑问题

3.7 WHEN 微信小程序中图片压缩成功 THEN 系统 SHALL CONTINUE TO 使用压缩后的图片进行后续处理

#### 7. 历史记录图片路径失效

3.8 WHEN 用户查看当前会话内的历史记录 THEN 系统 SHALL CONTINUE TO 正常显示图片

3.9 WHEN 用户点击历史记录项 THEN 系统 SHALL CONTINUE TO 正确跳转到游记详情页面

#### 8. 超时处理逻辑冲突

3.10 WHEN 用户点击"取消生成"按钮 THEN 系统 SHALL CONTINUE TO 正确中止请求并清理状态

3.11 WHEN 生成请求正常完成 THEN 系统 SHALL CONTINUE TO 显示生成结果并更新界面
