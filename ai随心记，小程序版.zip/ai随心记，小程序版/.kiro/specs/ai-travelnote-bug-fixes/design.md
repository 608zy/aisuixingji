# AI随行记综合BUG修复设计文档

## Overview

本设计文档针对"AI随行记"项目中的8个关键BUG提供系统化的修复方案。这些BUG涵盖：
1. API Key 安全泄露风险
2. API Key 验证用户体验问题
3. 图片处理超时导致功能失败
4. 云函数缺少错误处理导致崩溃
5. 测试连接参数不完整
6. 图片压缩失败处理不当
7. 历史记录图片路径失效
8. 超时处理逻辑冲突

修复策略采用最小化改动原则，确保现有功能不受影响的同时解决所有已知问题。

## Glossary

- **Bug_Condition (C)**: 触发BUG的条件集合 - 包括API Key硬编码、验证逻辑不当、超时设置过短、错误处理缺失等8种情况
- **Property (P)**: 修复后的期望行为 - API Key安全存储、友好的用户提示、合理的超时处理、完善的错误处理等
- **Preservation**: 必须保持不变的现有功能 - 正常的游记生成流程、图片处理、历史记录查看等核心功能
- **uni-app**: 跨平台应用开发框架，本项目基于此构建
- **云函数**: 部署在云端的 serverless 函数，用于调用 AI API
- **Base64**: 图片编码格式，用于在 API 请求中传输图片数据
- **临时路径**: 微信小程序提供的临时文件路径，应用关闭后失效

## Bug Details

### Bug Condition

本次修复涉及8个独立的BUG条件，每个都会导致不同的问题：

**Formal Specification:**
```
FUNCTION isBugCondition(input)
  INPUT: input of type SystemState
  OUTPUT: boolean
  
  RETURN (
    // Bug 1: API Key 硬编码在 package.json
    (input.apiKeyStorageLocation == "package.json" OR input.apiKeyStorageLocation == "source_code")
    
    // Bug 2: API Key 验证失败直接跳转
    OR (input.action == "generate_travel_note" AND NOT isValidApiKey(input.apiKey) AND input.userPromptShown == false)
    
    // Bug 3: 图片处理超时设置过短
    OR (input.imageProcessing == true AND input.timeout == 20000 AND (input.networkSpeed == "slow" OR input.imageSize == "large"))
    
    // Bug 4: 云函数缺少错误处理
    OR (input.cloudFunctionCalled == true AND input.apiResponse.choices == undefined AND input.errorHandling == false)
    
    // Bug 5: 测试连接缺少参数
    OR (input.action == "test_connection" AND input.parameters.address == undefined)
    
    // Bug 6: 图片压缩失败直接使用原图
    OR (input.imageCompression == "failed" AND input.fallbackStrategy == "use_original_base64")
    
    // Bug 7: 历史记录使用临时路径
    OR (input.historyRecord.imagePath STARTS_WITH "wxfile://" AND input.appRestarted == true)
    
    // Bug 8: 超时处理使用多个定时器
    OR (input.currentTimer != null AND input.fallbackTimer != null AND input.action IN ["generate", "regenerate"])
  )
END FUNCTION
```

### Examples

**Bug 1 - API Key 安全问题:**
- 当前: `package.json` 中包含 `"start": "API_KEY=sk-xxx node server.js"`
- 问题: API Key 被提交到 Git 仓库，任何有权限的人都能看到
- 预期: 使用 `.env` 文件存储，`.gitignore` 排除该文件

**Bug 2 - API Key 验证逻辑:**
- 当前: 用户点击"生成游记"，API Key 无效时直接 `uni.navigateTo('/pages/settings/settings')`
- 问题: 用户不知道为什么突然跳转，体验突兀
- 预期: 弹出模态对话框 "API Key 未配置或格式不正确，是否前往设置？"

**Bug 3 - 图片处理超时:**
- 当前: `setTimeout(() => resolve(null), 20000)` 在网络慢时导致图片处理失败
- 问题: 20秒对于大图片或慢网络不够，返回 null 导致生成失败
- 预期: 超时时间延长至 60 秒，超时后记录警告但继续处理其他图片

**Bug 4 - 云函数错误处理:**
- 当前: 直接访问 `res.data.choices[0].message.content` 不检查字段存在性
- 问题: API 返回异常格式时崩溃，用户收到不明确错误
- 预期: 先检查 `res.data?.choices?.[0]?.message?.content`，异常时返回明确错误信息

**Bug 5 - 测试连接参数:**
- 当前: 调用云函数时只传递 `{ apiKey, model, baseUrl }`
- 问题: 云函数需要 address 参数，缺失导致测试失败
- 预期: 传递完整参数 `{ apiKey, model, baseUrl, address: "测试地址" }`

**Bug 6 - 图片压缩失败:**
- 当前: 压缩失败后 `fs.readFileSync(imagePath, 'base64')` 读取原图
- 问题: 原图可能过大，Base64 后超出 API 请求限制
- 预期: 压缩失败后尝试降低质量重新压缩，仍失败则跳过该图片并记录警告

**Bug 7 - 历史记录图片路径:**
- 当前: 保存历史记录时使用 `wxfile://tmp_xxx` 临时路径
- 问题: 应用重启后临时路径失效，历史记录图片无法显示
- 预期: 将图片保存到持久化本地路径或上传到云存储

**Bug 8 - 超时处理逻辑:**
- 当前: 同时使用 `this.currentTimer` 和 `this.fallbackTimer` 两个定时器
- 问题: 定时器管理混乱，可能重复触发或遗漏清理
- 预期: 统一使用单一定时器 `this.generationTimer`，确保正确清理

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- 正常的游记生成流程必须继续工作（API Key 正确配置时）
- 图片处理成功时必须返回正确的 Base64 数据
- 历史记录的保存和查看功能必须继续工作
- 取消生成按钮必须正确中止请求
- 所有现有的用户界面交互必须保持一致

**Scope:**
所有不涉及上述8个BUG条件的输入和操作都应完全不受影响。这包括：
- 正常网络条件下的图片处理
- API 返回正常格式数据时的云函数处理
- 已正确配置 API Key 的用户的所有操作
- 当前会话内的历史记录查看
- 正常完成的生成请求

## Hypothesized Root Cause

基于BUG描述，最可能的根本原因分析：

### 1. API Key 安全问题
**Root Cause**: 开发者缺乏安全意识，直接在 npm scripts 中硬编码敏感信息
- 可能原因: 为了方便本地开发，没有考虑到代码会被提交到版本控制
- 影响: 严重的安全泄露风险

### 2. API Key 验证逻辑问题
**Root Cause**: 错误处理逻辑过于简单，直接跳转而不是友好提示
- 可能原因: 早期快速开发时采用的简单方案，未优化用户体验
- 影响: 用户体验差，不知道为什么突然跳转

### 3. 图片处理超时问题
**Root Cause**: 超时时间设置过于保守（20秒）
- 可能原因: 未充分测试慢网络或大图片场景
- 影响: 在实际使用中频繁超时失败

### 4. 云函数错误处理缺失
**Root Cause**: 缺少防御性编程，假设 API 总是返回正确格式
- 可能原因: 未考虑 API 异常情况或网络错误
- 影响: 云函数崩溃，用户收到不明确错误

### 5. 测试连接参数不完整
**Root Cause**: 前端调用云函数时参数传递不完整
- 可能原因: 测试连接功能复用了生成游记的云函数，但未传递所有必需参数
- 影响: 测试连接功能无法正常工作

### 6. 图片压缩失败兜底逻辑问题
**Root Cause**: 兜底策略不当，直接使用原图可能导致数据过大
- 可能原因: 未考虑原图大小可能超出 API 限制
- 影响: 压缩失败后整个生成流程失败

### 7. 历史记录图片路径失效
**Root Cause**: 使用微信小程序临时路径而不是持久化路径
- 可能原因: 未了解微信小程序临时路径的生命周期限制
- 影响: 应用重启后历史记录图片无法显示

### 8. 超时处理逻辑冲突
**Root Cause**: 代码重构或功能迭代时遗留了多个定时器
- 可能原因: 不同功能（生成、重生成）使用了不同的定时器变量，未统一管理
- 影响: 定时器管理混乱，可能导致内存泄漏

## Correctness Properties

Property 1: Bug Condition - 综合BUG修复

_For any_ 系统状态 input 满足 isBugCondition(input) 返回 true（即触发8个BUG中的任意一个），修复后的系统 SHALL 表现出正确的行为：API Key 安全存储、友好的用户提示、合理的超时处理、完善的错误处理、完整的参数传递、正确的兜底策略、持久化的图片路径、统一的定时器管理。

**Validates: Requirements 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 2.10, 2.11, 2.12, 2.13, 2.14, 2.15**

Property 2: Preservation - 现有功能保持不变

_For any_ 系统状态 input 不满足 isBugCondition(input)（即不触发任何BUG条件），修复后的系统 SHALL 产生与原系统完全相同的结果，保持所有现有功能的正常运行，包括游记生成、图片处理、历史记录查看、请求取消等核心功能。

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 3.10, 3.11**

## Fix Implementation

### Changes Required

假设我们的根本原因分析正确，以下是具体的修复方案：

#### Bug 1: API Key 安全问题

**File**: `backend/package.json`, `backend/.env`, `backend/.gitignore`

**Specific Changes**:
1. **创建 .env 文件**: 在 backend 目录下创建 `.env` 文件存储 API Key
   ```
   API_KEY=your_api_key_here
   BASE_URL=your_base_url_here
   ```

2. **修改 package.json**: 移除硬编码的 API Key，使用环境变量
   ```json
   "scripts": {
     "start": "node -r dotenv/config server.js"
   }
   ```

3. **添加 .gitignore**: 确保 `.env` 文件不被提交
   ```
   .env
   ```

4. **创建 .env.example**: 提供配置模板
   ```
   API_KEY=
   BASE_URL=
   ```

5. **安装 dotenv**: `npm install dotenv` 用于加载环境变量

#### Bug 2: API Key 验证逻辑问题

**File**: `pages/index/index.vue` (或主页面文件)

**Function**: `generateTravelNote` 或类似的生成游记方法

**Specific Changes**:
1. **替换直接跳转为模态对话框**:
   ```javascript
   // 原代码
   if (!isValidApiKey(apiKey)) {
     uni.navigateTo({ url: '/pages/settings/settings' });
     return;
   }
   
   // 修复后
   if (!isValidApiKey(apiKey)) {
     uni.showModal({
       title: '提示',
       content: 'API Key 未配置或格式不正确，是否前往设置？',
       confirmText: '去设置',
       cancelText: '取消',
       success: (res) => {
         if (res.confirm) {
           uni.navigateTo({ url: '/pages/settings/settings' });
         }
       }
     });
     return;
   }
   ```

#### Bug 3: 图片处理超时问题

**File**: `utils/imageProcessor.js` (或类似的图片处理工具文件)

**Function**: `processImage` 或类似的图片处理方法

**Specific Changes**:
1. **延长超时时间**: 从 20 秒延长至 60 秒
   ```javascript
   // 原代码
   setTimeout(() => resolve(null), 20000);
   
   // 修复后
   setTimeout(() => {
     console.warn('图片处理超时，跳过该图片');
     resolve(null);
   }, 60000);
   ```

2. **改进超时处理**: 超时后记录警告但不阻塞流程
   - 确保返回 null 时，调用方能够继续处理其他图片
   - 在生成游记时过滤掉 null 值

#### Bug 4: 云函数错误处理缺失

**File**: `cloudfunctions/generateTravelNote/index.js` (或类似的云函数文件)

**Specific Changes**:
1. **添加防御性检查**:
   ```javascript
   // 原代码
   const content = res.data.choices[0].message.content;
   
   // 修复后
   if (!res.data || !res.data.choices || !Array.isArray(res.data.choices) || res.data.choices.length === 0) {
     return {
       success: false,
       error: 'API 返回格式异常',
       details: 'API 响应缺少 choices 字段或格式不正确'
     };
   }
   
   const choice = res.data.choices[0];
   if (!choice.message || !choice.message.content) {
     return {
       success: false,
       error: 'API 返回格式异常',
       details: 'API 响应缺少 message.content 字段'
     };
   }
   
   const content = choice.message.content;
   ```

2. **统一错误返回格式**: 确保所有错误都返回 `{ success: false, error: string, details: string }`

#### Bug 5: 测试连接参数不完整

**File**: `pages/settings/settings.vue` (或设置页面文件)

**Function**: `testConnection` 或类似的测试连接方法

**Specific Changes**:
1. **添加缺失的 address 参数**:
   ```javascript
   // 原代码
   const result = await uniCloud.callFunction({
     name: 'generateTravelNote',
     data: {
       apiKey: this.apiKey,
       model: this.model,
       baseUrl: this.baseUrl
     }
   });
   
   // 修复后
   const result = await uniCloud.callFunction({
     name: 'generateTravelNote',
     data: {
       apiKey: this.apiKey,
       model: this.model,
       baseUrl: this.baseUrl,
       address: '测试地址',
       images: [],
       isTest: true  // 添加标志位表示这是测试请求
     }
   });
   ```

#### Bug 6: 图片压缩失败兜底逻辑问题

**File**: `utils/imageProcessor.js` (或类似的图片处理工具文件)

**Function**: 图片压缩相关方法

**Specific Changes**:
1. **改进兜底策略**:
   ```javascript
   // 原代码
   try {
     // 压缩逻辑
   } catch (error) {
     return fs.readFileSync(imagePath, 'base64');
   }
   
   // 修复后
   try {
     // 压缩逻辑
   } catch (error) {
     console.warn('图片压缩失败，尝试降低质量重新压缩');
     try {
       // 尝试更低质量压缩
       const result = await uni.compressImage({
         src: imagePath,
         quality: 50  // 降低质量
       });
       return fs.readFileSync(result.tempFilePath, 'base64');
     } catch (retryError) {
       console.error('重试压缩仍失败，跳过该图片');
       return null;  // 跳过该图片而不是使用原图
     }
   }
   ```

2. **在调用方过滤 null 值**: 确保跳过的图片不会导致整体流程失败

#### Bug 7: 历史记录图片路径失效

**File**: `pages/index/index.vue` (或保存历史记录的文件)

**Function**: `saveToHistory` 或类似的保存历史记录方法

**Specific Changes**:
1. **将临时路径转换为持久化路径**:
   ```javascript
   // 原代码
   const historyItem = {
     images: this.selectedImages,  // 直接保存临时路径
     content: result.content,
     timestamp: Date.now()
   };
   
   // 修复后
   const persistentImages = await Promise.all(
     this.selectedImages.map(async (tempPath) => {
       const fileName = `history_${Date.now()}_${Math.random().toString(36).substr(2, 9)}.jpg`;
       const savedPath = `${wx.env.USER_DATA_PATH}/${fileName}`;
       await wx.getFileSystemManager().copyFile({
         srcPath: tempPath,
         destPath: savedPath
       });
       return savedPath;
     })
   );
   
   const historyItem = {
     images: persistentImages,  // 保存持久化路径
     content: result.content,
     timestamp: Date.now()
   };
   ```

2. **或使用云存储方案**: 如果项目已配置云存储，可以上传到云端

#### Bug 8: 超时处理逻辑冲突

**File**: `pages/index/index.vue` (或主页面文件)

**Function**: `generateTravelNote`, `regenerateByAdvice` 等方法

**Specific Changes**:
1. **统一定时器管理**:
   ```javascript
   // 原代码
   this.currentTimer = setTimeout(...);
   this.fallbackTimer = setTimeout(...);
   
   // 修复后
   // 清理旧定时器
   if (this.generationTimer) {
     clearTimeout(this.generationTimer);
     this.generationTimer = null;
   }
   
   // 设置新定时器
   this.generationTimer = setTimeout(() => {
     // 超时处理逻辑
   }, 60000);
   ```

2. **确保定时器清理**:
   ```javascript
   // 在请求完成、取消、或组件销毁时清理
   onUnmounted(() => {
     if (this.generationTimer) {
       clearTimeout(this.generationTimer);
       this.generationTimer = null;
     }
   });
   ```

## Testing Strategy

### Validation Approach

测试策略采用两阶段方法：首先在未修复的代码上运行探索性测试以确认BUG存在，然后验证修复后的代码能够正确处理BUG条件并保持现有功能不变。

### Exploratory Bug Condition Checking

**Goal**: 在实施修复之前，在未修复的代码上演示这8个BUG的存在。确认或反驳根本原因分析。如果反驳，需要重新假设。

**Test Plan**: 编写测试用例模拟每个BUG条件，在未修复的代码上运行以观察失败并理解根本原因。

**Test Cases**:

1. **API Key 安全测试**: 检查 package.json 和 Git 历史中是否存在硬编码的 API Key（将在未修复代码上发现）

2. **API Key 验证逻辑测试**: 模拟 API Key 无效时点击生成按钮，观察是否直接跳转而不是弹窗提示（将在未修复代码上失败）

3. **图片处理超时测试**: 模拟慢网络或大图片场景，观察是否在 20 秒后超时返回 null（将在未修复代码上失败）

4. **云函数错误处理测试**: 模拟 API 返回异常格式（缺少 choices 字段），观察云函数是否崩溃（将在未修复代码上失败）

5. **测试连接参数测试**: 调用测试连接功能，检查云函数调用参数是否缺少 address（将在未修复代码上失败）

6. **图片压缩失败测试**: 模拟压缩失败场景，观察是否直接使用原图导致数据过大（将在未修复代码上失败）

7. **历史记录图片路径测试**: 保存历史记录后重启应用，观察图片是否失效（将在未修复代码上失败）

8. **超时处理逻辑测试**: 检查代码中是否同时存在 currentTimer 和 fallbackTimer（将在未修复代码上发现）

**Expected Counterexamples**:
- API Key 出现在 package.json 或 Git 历史中
- API Key 无效时直接跳转而不是弹窗
- 图片处理在 20 秒后超时失败
- 云函数在 API 返回异常时崩溃
- 测试连接因缺少参数而失败
- 压缩失败后使用原图导致请求失败
- 应用重启后历史记录图片无法显示
- 多个定时器同时存在导致管理混乱

### Fix Checking

**Goal**: 验证对于所有满足BUG条件的输入，修复后的系统能够产生期望的正确行为。

**Pseudocode:**
```
FOR ALL input WHERE isBugCondition(input) DO
  result := fixedSystem(input)
  ASSERT expectedBehavior(result)
END FOR
```

**Test Cases**:
1. 验证 API Key 存储在 .env 文件中且 .env 在 .gitignore 中
2. 验证 API Key 无效时弹出模态对话框而不是直接跳转
3. 验证图片处理超时时间延长至 60 秒且超时后记录警告
4. 验证云函数在 API 返回异常时返回明确错误信息而不是崩溃
5. 验证测试连接传递完整参数包括 address
6. 验证图片压缩失败后尝试降低质量重新压缩，仍失败则跳过
7. 验证历史记录使用持久化路径且应用重启后图片正常显示
8. 验证只使用单一定时器且请求完成后正确清理

### Preservation Checking

**Goal**: 验证对于所有不满足BUG条件的输入，修复后的系统产生与原系统完全相同的结果。

**Pseudocode:**
```
FOR ALL input WHERE NOT isBugCondition(input) DO
  ASSERT originalSystem(input) = fixedSystem(input)
END FOR
```

**Testing Approach**: 推荐使用基于属性的测试进行保持性检查，因为：
- 它自动生成大量测试用例覆盖输入域
- 它能捕获手动单元测试可能遗漏的边缘情况
- 它提供强有力的保证，确保所有非BUG输入的行为保持不变

**Test Plan**: 首先在未修复的代码上观察正常场景的行为，然后编写基于属性的测试捕获该行为。

**Test Cases**:

1. **正常游记生成保持性**: 观察 API Key 正确配置时的生成流程在未修复代码上正常工作，然后验证修复后继续正常工作

2. **图片处理成功保持性**: 观察正常网络和图片大小时的处理在未修复代码上正常工作，然后验证修复后继续返回正确的 Base64 数据

3. **历史记录查看保持性**: 观察当前会话内的历史记录查看在未修复代码上正常工作，然后验证修复后继续正常显示

4. **请求取消保持性**: 观察取消生成按钮在未修复代码上正常工作，然后验证修复后继续正确中止请求

5. **云函数正常响应保持性**: 观察 API 返回正常格式时的处理在未修复代码上正常工作，然后验证修复后继续正确提取内容

### Unit Tests

- 测试 .env 文件加载和环境变量读取
- 测试 API Key 验证逻辑和模态对话框显示
- 测试图片处理超时时间和警告日志
- 测试云函数错误处理的各种异常情况
- 测试测试连接参数的完整性
- 测试图片压缩失败的兜底逻辑
- 测试历史记录图片路径的持久化
- 测试定时器的创建和清理

### Property-Based Tests

- 生成随机的 API 响应格式，验证云函数错误处理的健壮性
- 生成随机的图片大小和网络条件，验证超时处理的正确性
- 生成随机的用户操作序列，验证定时器管理的正确性
- 生成随机的历史记录数据，验证图片路径持久化的正确性

### Integration Tests

- 测试完整的游记生成流程（从拍照到生成到保存历史记录）
- 测试 API Key 配置流程（从设置到测试连接到实际使用）
- 测试应用重启后的历史记录查看流程
- 测试各种异常情况下的用户体验（网络错误、API 错误、超时等）
