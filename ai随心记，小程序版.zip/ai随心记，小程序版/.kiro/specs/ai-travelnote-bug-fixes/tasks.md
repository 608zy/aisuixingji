# AI随行记综合BUG修复 - 实施计划

## 探索阶段

- [x] 1. 编写BUG条件探索测试（修复前运行）
  - **Property 1: Bug Condition** - 综合BUG条件验证
  - **重要**: 在实施任何修复之前编写此基于属性的测试
  - **目标**: 展示8个BUG的存在，确认根本原因分析
  - **作用域化PBT方法**: 针对每个BUG创建具体的失败案例测试
  - **测试内容**:
    - Bug 1: 检查 package.json 中是否硬编码 API Key
    - Bug 2: 模拟 API Key 无效时点击生成，验证是否直接跳转（而非弹窗）
    - Bug 3: 模拟慢网络/大图片，验证是否在 20 秒超时返回 null
    - Bug 4: 模拟 API 返回缺少 choices 字段，验证云函数是否崩溃
    - Bug 5: 调用测试连接，验证是否缺少 address 参数
    - Bug 6: 模拟压缩失败，验证是否直接使用原图导致数据过大
    - Bug 7: 保存历史记录后重启应用，验证图片路径是否失效
    - Bug 8: 检查代码中是否同时存在 currentTimer 和 fallbackTimer
  - 在未修复的代码上运行测试 - 预期失败（这证明BUG存在）
  - 记录发现的反例（例如："package.json 包含硬编码的 API Key"）
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10, 1.11, 1.12, 1.13, 1.14, 1.15_

## 保持性测试阶段

- [x] 2. 编写保持性属性测试（修复前运行）
  - **Property 2: Preservation** - 现有功能保持不变
  - **重要**: 遵循观察优先方法论
  - **观察**: 在未修复的代码上运行正常场景，记录实际输出
    - 观察: API Key 正确配置时游记生成流程正常工作
    - 观察: 正常网络和图片大小时处理成功返回 Base64 数据
    - 观察: 当前会话内历史记录查看正常显示
    - 观察: 取消生成按钮正确中止请求
    - 观察: API 返回正常格式时云函数正确提取内容
  - 编写基于属性的测试: 对于所有非BUG条件的输入，验证行为保持不变
  - 在未修复的代码上验证测试通过
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 3.10, 3.11_

## 实施阶段

- [x] 3. 修复 Bug 1: API Key 安全问题

  - [x] 3.1 创建环境变量配置
    - 在 backend 目录创建 `.env` 文件存储 API Key
    - 添加 API_KEY 和 BASE_URL 环境变量
    - 创建 `.env.example` 作为配置模板
    - _Bug_Condition: input.apiKeyStorageLocation == "package.json" OR "source_code"_
    - _Expected_Behavior: API Key 存储在 .env 文件中，不出现在代码仓库_
    - _Preservation: npm scripts 启动后端服务继续正常工作_
    - _Requirements: 1.1, 1.2, 2.1, 2.2, 3.1_

  - [x] 3.2 修改 package.json 使用环境变量
    - 移除硬编码的 API Key
    - 修改 start 脚本使用 `node -r dotenv/config server.js`
    - 安装 dotenv 依赖: `npm install dotenv`
    - _Requirements: 1.1, 2.1, 3.1_

  - [x] 3.3 更新 .gitignore
    - 添加 `.env` 到 .gitignore
    - 确保 .env 文件不会被提交到版本控制
    - _Requirements: 1.2, 2.2_

- [x] 4. 修复 Bug 2: API Key 验证逻辑问题

  - [x] 4.1 改进 API Key 验证用户体验
    - 定位 `pages/index/index.vue` 中的 generateTravelNote 方法
    - 将直接跳转 `uni.navigateTo` 替换为 `uni.showModal` 模态对话框
    - 添加"去设置"和"取消"选项
    - 用户确认后才跳转到设置页面
    - _Bug_Condition: input.action == "generate_travel_note" AND NOT isValidApiKey AND input.userPromptShown == false_
    - _Expected_Behavior: 弹出模态对话框提示用户，提供"去设置"和"取消"选项_
    - _Preservation: API Key 正确配置时直接调用 AI API 生成游记_
    - _Requirements: 1.3, 2.3, 3.2_

- [x] 5. 修复 Bug 3: 图片处理超时问题

  - [x] 5.1 延长图片处理超时时间
    - 定位 `utils/imageProcessor.js` 中的图片处理方法
    - 将超时时间从 20000ms 延长至 60000ms
    - 超时时记录警告日志: `console.warn('图片处理超时，跳过该图片')`
    - 确保返回 null 时调用方能继续处理其他图片
    - _Bug_Condition: input.imageProcessing == true AND input.timeout == 20000 AND (networkSpeed == "slow" OR imageSize == "large")_
    - _Expected_Behavior: 超时时间延长至 60 秒，超时后记录警告并继续处理_
    - _Preservation: 正常网络和图片大小时继续在合理时间内完成处理_
    - _Requirements: 1.4, 1.5, 2.4, 2.5, 3.3, 3.4_

- [x] 6. 修复 Bug 4: 云函数错误处理缺失

  - [x] 6.1 添加云函数防御性检查
    - 定位 `cloudfunctions/generateTravelNote/index.js`
    - 在访问 `res.data.choices[0].message.content` 前添加字段存在性检查
    - 检查 res.data、res.data.choices、choices 数组长度
    - 检查 choice.message 和 choice.message.content
    - 异常时返回明确错误: `{ success: false, error: 'API 返回格式异常', details: '...' }`
    - _Bug_Condition: input.cloudFunctionCalled == true AND input.apiResponse.choices == undefined AND input.errorHandling == false_
    - _Expected_Behavior: 先检查字段存在性，异常时返回明确错误信息_
    - _Preservation: API 返回正常格式时继续正确提取内容_
    - _Requirements: 1.6, 1.7, 2.6, 2.7, 3.5_

- [x] 7. 修复 Bug 5: 测试连接参数不完整

  - [x] 7.1 补充测试连接缺失参数
    - 定位 `pages/settings/settings.vue` 中的 testConnection 方法
    - 在调用云函数时添加 address 参数: `address: '测试地址'`
    - 添加 images: [] 和 isTest: true 标志位
    - 确保传递完整参数: { apiKey, model, baseUrl, address, images, isTest }
    - _Bug_Condition: input.action == "test_connection" AND input.parameters.address == undefined_
    - _Expected_Behavior: 传递完整参数包括 address，测试连接成功显示"云端就绪"_
    - _Preservation: 保存 API Key 配置继续正确存储到本地_
    - _Requirements: 1.8, 1.9, 2.8, 2.9, 3.6_

- [x] 8. 修复 Bug 6: 图片压缩失败兜底逻辑问题

  - [x] 8.1 改进图片压缩失败处理策略
    - 定位 `utils/imageProcessor.js` 中的图片压缩方法
    - 压缩失败时先尝试降低质量参数（quality: 50）重新压缩
    - 重试仍失败则返回 null 跳过该图片，而不是使用原图
    - 记录警告: `console.error('重试压缩仍失败，跳过该图片')`
    - 在调用方过滤 null 值，确保跳过的图片不影响整体流程
    - _Bug_Condition: input.imageCompression == "failed" AND input.fallbackStrategy == "use_original_base64"_
    - _Expected_Behavior: 压缩失败后尝试降低质量重新压缩，仍失败则跳过该图片_
    - _Preservation: 压缩成功时继续使用压缩后的图片_
    - _Requirements: 1.10, 1.11, 2.10, 2.11, 3.7_

- [x] 9. 修复 Bug 7: 历史记录图片路径失效

  - [x] 9.1 实现图片路径持久化
    - 定位 `pages/index/index.vue` 中的 saveToHistory 方法
    - 将临时路径 `wxfile://tmp_xxx` 转换为持久化路径
    - 使用 `wx.env.USER_DATA_PATH` 创建持久化文件名
    - 使用 `wx.getFileSystemManager().copyFile` 复制文件到持久化路径
    - 保存持久化路径到历史记录而不是临时路径
    - _Bug_Condition: input.historyRecord.imagePath STARTS_WITH "wxfile://" AND input.appRestarted == true_
    - _Expected_Behavior: 将图片保存到持久化本地路径，应用重启后图片正常显示_
    - _Preservation: 当前会话内历史记录查看继续正常显示，点击历史记录项继续正确跳转_
    - _Requirements: 1.12, 1.13, 2.12, 2.13, 3.8, 3.9_

- [x] 10. 修复 Bug 8: 超时处理逻辑冲突

  - [x] 10.1 统一定时器管理
    - 定位 `pages/index/index.vue` 中的 generateTravelNote 和 regenerateByAdvice 方法
    - 移除 currentTimer 和 fallbackTimer，统一使用 generationTimer
    - 设置新定时器前先清理旧定时器: `clearTimeout(this.generationTimer)`
    - 在请求完成、取消、或组件销毁时清理定时器
    - 在 onUnmounted 生命周期钩子中添加清理逻辑
    - _Bug_Condition: input.currentTimer != null AND input.fallbackTimer != null AND input.action IN ["generate", "regenerate"]_
    - _Expected_Behavior: 统一使用单一定时器，确保正确清理避免内存泄漏_
    - _Preservation: 取消生成按钮继续正确中止请求，生成请求正常完成继续显示结果_
    - _Requirements: 1.14, 1.15, 2.14, 2.15, 3.10, 3.11_

  - [x] 10.2 验证BUG条件探索测试现在通过
    - **Property 1: Expected Behavior** - 综合BUG修复验证
    - **重要**: 重新运行任务 1 中的相同测试 - 不要编写新测试
    - 任务 1 中的测试编码了期望行为
    - 当此测试通过时，确认期望行为得到满足
    - 运行任务 1 中的BUG条件探索测试
    - **预期结果**: 测试通过（确认所有BUG已修复）
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 2.10, 2.11, 2.12, 2.13, 2.14, 2.15_

  - [x] 10.3 验证保持性测试仍然通过
    - **Property 2: Preservation** - 现有功能保持不变
    - **重要**: 重新运行任务 2 中的相同测试 - 不要编写新测试
    - 运行任务 2 中的保持性属性测试
    - **预期结果**: 测试通过（确认无回归）
    - 确认修复后所有测试仍然通过（无回归）

## 检查点

- [x] 11. 确保所有测试通过
  - 运行所有探索测试、保持性测试和单元测试
  - 验证所有8个BUG已修复且无回归
  - 如有问题请咨询用户
