# 设计文档

## 概述

本设计文档描述了 AI 随行记小程序的架构优化和功能增强方案。该项目基于 uni-app 框架开发，使用 uniCloud 作为后端服务，通过 WeAPIs（OpenAI 兼容接口）调用 AI 能力生成旅游游记。

### 设计目标

1. **简化架构**: 移除冗余的 Node.js 后端，统一使用 uniCloud 云函数
2. **增强体验**: 添加生成进度提示、游记模板选择等功能
3. **数据同步**: 实现本地存储与云数据库的双向同步
4. **代码质量**: 优化代码结构，提高可维护性和可读性
5. **错误处理**: 统一错误处理机制，提供友好的用户提示

### 技术栈

- **前端框架**: uni-app (Vue 3)
- **后端服务**: uniCloud (阿里云)
- **数据库**: uniCloud DB
- **用户认证**: uni-id
- **AI 服务**: WeAPIs (OpenAI 兼容接口)
- **存储**: uni.storage (本地) + uniCloud DB (云端)

## 架构设计

### 当前架构问题

当前项目存在以下架构问题：

1. **双后端冗余**: 同时维护 Node.js 后端 (backend/server.js) 和 uniCloud 云函数，代码重复
2. **条件判断复杂**: 前端代码中存在大量 `use_backend` 条件判断，增加维护成本
3. **请求路径混乱**: API 请求可能走 Node.js 后端或云函数，逻辑不清晰

### 优化后架构

```
┌─────────────────────────────────────────────────────────────┐
│                        uni-app 前端                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ 首页组件 │  │ 历史页面 │  │ 设置页面 │  │ 我的页面 │   │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘   │
│       │             │             │             │           │
│       └─────────────┴─────────────┴─────────────┘           │
│                         │                                    │
│              ┌──────────┴──────────┐                        │
│              │                     │                        │
│         ┌────▼────┐          ┌────▼────┐                   │
│         │ API 模块 │          │工具模块 │                   │
│         │(api.js) │          │(utils)  │                   │
│         └────┬────┘          └─────────┘                   │
│              │                                              │
└──────────────┼──────────────────────────────────────────────┘
               │
               │ uniCloud.callFunction()
               │
┌──────────────▼──────────────────────────────────────────────┐
│                      uniCloud 云端                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ generate-note│  │  sync-notes  │  │  uni-id 认证 │     │
│  │   云函数     │  │   云函数     │  │    云函数    │     │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘     │
│         │                  │                  │             │
│         │                  │                  │             │
│  ┌──────▼──────────────────▼──────────────────▼───────┐   │
│  │              uniCloud 数据库                        │   │
│  │  ┌──────────────┐  ┌──────────────┐               │   │
│  │  │ travel_notes │  │ uni-id-users │               │   │
│  │  │     表       │  │     表       │               │   │
│  │  └──────────────┘  └──────────────┘               │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
               │
               │ HTTP Request
               │
┌──────────────▼──────────────────────────────────────────────┐
│                      WeAPIs 服务                             │
│                  (OpenAI 兼容接口)                           │
└─────────────────────────────────────────────────────────────┘
```

### 架构优化要点

1. **移除 Node.js 后端**: 删除 backend/ 目录，所有后端逻辑迁移到云函数
2. **统一请求路径**: 所有 API 请求通过 `uniCloud.callFunction()` 调用云函数
3. **简化前端代码**: 移除 `use_backend` 条件判断，简化 `apiRequest` 方法
4. **模块化设计**: 将 API 调用、工具函数、常量定义分离到独立模块

## 组件和接口设计

### 前端模块结构

```
pages/
├── index/
│   └── index.vue          # 首页：图片选择、位置获取、游记生成
├── me/
│   └── me.vue             # 我的页面：用户信息、登录/退出
├── settings/
│   └── settings.vue       # 设置页面：模型选择、历史记录
└── note/
    └── note.vue           # 游记详情页：查看和编辑游记

utils/
├── api.js                 # API 调用封装
├── constants.js           # 常量定义
├── templates.js           # 游记模板配置
├── error-handler.js       # 统一错误处理
└── sync-service.js        # 数据同步服务

uniCloud-aliyun/
└── cloudfunctions/
    ├── generate-note/     # 游记生成云函数
    │   └── index.js
    └── sync-notes/        # 数据同步云函数
        └── index.js
```

### 核心组件设计

#### 1. 游记生成器 (GenerateNoteService)

负责调用 AI API 生成游记内容，支持进度提示和模板选择。

**接口定义**:
```javascript
class GenerateNoteService {
  /**
   * 生成游记
   * @param {Object} options - 生成选项
   * @param {string} options.address - 地点信息
   * @param {Array<string>} options.imageUrls - 图片 URL 数组
   * @param {string} options.template - 模板 ID
   * @param {Function} options.onProgress - 进度回调
   * @returns {Promise<string>} 生成的游记内容
   */
  async generate(options)
  
  /**
   * 根据反馈重新生成
   * @param {Object} options - 生成选项
   * @param {string} options.address - 地点信息
   * @param {Array<string>} options.imageUrls - 图片 URL 数组
   * @param {string} options.feedbackText - 用户反馈
   * @param {Function} options.onProgress - 进度回调
   * @returns {Promise<string>} 生成的游记内容
   */
  async regenerateWithFeedback(options)
}
```

**进度阶段定义**:
```javascript
const PROGRESS_STAGES = {
  ANALYZING: { text: '正在分析图片...', progress: 20 },
  CREATING: { text: '正在创作...', progress: 60 },
  FINISHING: { text: '即将完成...', progress: 90 },
  COMPLETED: { text: '生成完成', progress: 100 }
}
```

#### 2. 模板引擎 (TemplateEngine)

根据用户选择的写作风格构建 AI prompt。

**模板配置**:
```javascript
const TEMPLATES = {
  literary: {
    id: 'literary',
    name: '文艺风',
    description: '优雅细腻，富有诗意和情感',
    prompt: '请用优雅细腻的文艺笔触，写一段富有诗意和情感的旅行随笔。注重细节描写和情感表达，语言优美但不过分矫情。',
    example: '阳光透过梧桐叶的缝隙，在青石板路上投下斑驳的光影...'
  },
  humorous: {
    id: 'humorous',
    name: '幽默风',
    description: '轻松诙谐，充满趣味和调侃',
    prompt: '请用轻松诙谐的幽默笔触，写一段充满趣味的旅行随笔。可以适当调侃和自嘲，让读者会心一笑。',
    example: '说好的"人间仙境"，结果我只看到了人间和人...'
  },
  concise: {
    id: 'concise',
    name: '简洁风',
    description: '简明扼要，直击重点',
    prompt: '请用简明扼要的笔触，写一段直击重点的旅行随笔。语言精练，不拖泥带水，突出核心体验。',
    example: '到了。看了。值了。'
  },
  poetic: {
    id: 'poetic',
    name: '诗意风',
    description: '意境深远，充满想象力',
    prompt: '请用充满诗意的笔触，写一段意境深远的旅行随笔。注重意象和氛围营造，语言富有韵律感。',
    example: '风吹过山谷，带来远方的呼唤。我在这里，听见了时间的声音...'
  }
}
```

**接口定义**:
```javascript
class TemplateEngine {
  /**
   * 构建 AI prompt
   * @param {string} templateId - 模板 ID
   * @param {string} address - 地点信息
   * @param {string} feedbackText - 用户反馈（可选）
   * @returns {string} 构建好的 prompt
   */
  buildPrompt(templateId, address, feedbackText = '')
  
  /**
   * 获取所有模板
   * @returns {Array<Object>} 模板列表
   */
  getAllTemplates()
  
  /**
   * 获取默认模板 ID
   * @returns {string} 默认模板 ID
   */
  getDefaultTemplateId()
}
```

#### 3. 历史记录管理器 (HistoryManager)

管理用户的历史游记，支持本地存储和云端同步。

**接口定义**:
```javascript
class HistoryManager {
  /**
   * 保存游记到本地
   * @param {Object} note - 游记对象
   * @returns {Promise<void>}
   */
  async saveToLocal(note)
  
  /**
   * 从本地获取历史记录
   * @returns {Promise<Array<Object>>} 历史记录列表
   */
  async getLocalHistory()
  
  /**
   * 清空本地历史记录
   * @returns {Promise<void>}
   */
  async clearLocalHistory()
  
  /**
   * 同步到云端
   * @param {Array<Object>} notes - 待同步的游记列表
   * @returns {Promise<void>}
   */
  async syncToCloud(notes)
  
  /**
   * 从云端拉取
   * @returns {Promise<Array<Object>>} 云端历史记录列表
   */
  async fetchFromCloud()
  
  /**
   * 合并本地和云端数据
   * @param {Array<Object>} localNotes - 本地游记列表
   * @param {Array<Object>} cloudNotes - 云端游记列表
   * @returns {Array<Object>} 合并后的游记列表
   */
  mergeNotes(localNotes, cloudNotes)
}
```

#### 4. 同步服务 (SyncService)

在本地存储和云数据库之间同步数据。

**同步策略**:
- **未登录**: 仅使用本地存储
- **登录后**: 自动将本地未同步的游记上传到云端
- **数据冲突**: 以云端数据为准，本地数据作为补充
- **网络异常**: 继续使用本地存储，网络恢复后自动同步

**接口定义**:
```javascript
class SyncService {
  /**
   * 执行完整同步
   * @returns {Promise<Object>} 同步结果
   */
  async performFullSync()
  
  /**
   * 上传本地未同步的游记
   * @returns {Promise<number>} 上传的游记数量
   */
  async uploadLocalNotes()
  
  /**
   * 下载云端游记
   * @returns {Promise<Array<Object>>} 云端游记列表
   */
  async downloadCloudNotes()
  
  /**
   * 检查同步状态
   * @returns {Promise<Object>} 同步状态信息
   */
  async checkSyncStatus()
}
```

#### 5. 错误处理器 (ErrorHandler)

统一处理所有错误情况，提供友好的用户提示。

**错误类型定义**:
```javascript
const ERROR_TYPES = {
  NETWORK_TIMEOUT: {
    code: 'NETWORK_TIMEOUT',
    message: '网络连接超时，请检查网络设置',
    retry: true
  },
  CLOUD_FUNCTION_ERROR: {
    code: 'CLOUD_FUNCTION_ERROR',
    message: '云函数调用失败',
    retry: true
  },
  AI_API_ERROR: {
    code: 'AI_API_ERROR',
    message: 'AI 服务暂时不可用',
    retry: true
  },
  MISSING_PARAMS: {
    code: 'MISSING_PARAMS',
    message: '缺少必要参数',
    retry: false
  },
  PERMISSION_DENIED: {
    code: 'PERMISSION_DENIED',
    message: '权限不足',
    retry: false
  },
  UNKNOWN_ERROR: {
    code: 'UNKNOWN_ERROR',
    message: '未知错误，请稍后重试',
    retry: true
  }
}
```

**接口定义**:
```javascript
class ErrorHandler {
  /**
   * 处理错误
   * @param {Error} error - 错误对象
   * @param {Object} context - 错误上下文
   * @returns {Object} 处理后的错误信息
   */
  handle(error, context = {})
  
  /**
   * 显示错误提示
   * @param {Object} errorInfo - 错误信息
   * @param {boolean} showRetry - 是否显示重试按钮
   */
  showError(errorInfo, showRetry = false)
  
  /**
   * 记录错误日志
   * @param {Error} error - 错误对象
   * @param {Object} context - 错误上下文
   * @returns {Promise<void>}
   */
  async logError(error, context = {})
}
```

### 云函数设计

#### 1. generate-note 云函数

负责调用 AI API 生成游记内容。

**输入参数**:
```javascript
{
  address: string,        // 地点信息
  imageUrls: string[],    // 图片 URL 数组（最多 3 张）
  template: string,       // 模板 ID
  feedbackText: string,   // 用户反馈（可选）
  apiKey: string,         // API Key
  model: string,          // AI 模型
  baseUrl: string         // API 地址
}
```

**输出结果**:
```javascript
{
  ok: boolean,           // 是否成功
  content: string,       // 生成的游记内容
  provider: string,      // 服务提供商
  model: string,         // 使用的模型
  error: string,         // 错误信息（失败时）
  message: string        // 详细错误描述（失败时）
}
```

#### 2. sync-notes 云函数

负责同步用户的历史游记数据。

**输入参数**:
```javascript
{
  action: string,        // 操作类型：'upload' | 'download' | 'merge'
  notes: Array<Object>   // 游记列表（upload 时需要）
}
```

**输出结果**:
```javascript
{
  ok: boolean,           // 是否成功
  action: string,        // 操作类型
  data: Array<Object>,   // 返回的数据（download/merge 时）
  count: number,         // 处理的记录数
  error: string,         // 错误信息（失败时）
  message: string        // 详细错误描述（失败时）
}
```

## 数据模型

### 本地存储数据结构

#### travel_history (本地存储 key)

存储用户的历史游记记录。

```javascript
{
  id: string,              // 游记 ID（时间戳）
  time: string,            // 创建时间（本地时间字符串）
  address: string,         // 地点信息
  content: string,         // 游记内容
  cover: string,           // 封面图片路径
  template: string,        // 使用的模板 ID
  synced: boolean,         // 是否已同步到云端
  updated_at: number       // 最后更新时间（时间戳）
}
```

#### weapis_model (本地存储 key)

存储用户选择的 AI 模型。

```javascript
string  // 模型名称，如 'gpt-4o-mini'
```

#### last_template (本地存储 key)

存储用户最近一次选择的模板。

```javascript
string  // 模板 ID，如 'literary'
```

#### uni_id_token (本地存储 key)

存储用户登录 token（由 uni-id 管理）。

```javascript
string  // JWT token
```

### 云数据库表结构

#### travel_notes 表

存储用户的游记数据。

**表结构**:
```json
{
  "bsonType": "object",
  "required": ["user_id", "content", "created_at"],
  "permission": {
    "read": "doc.user_id == auth.uid",
    "create": true,
    "update": "doc.user_id == auth.uid",
    "delete": "doc.user_id == auth.uid"
  },
  "properties": {
    "_id": {
      "bsonType": "string",
      "description": "游记 ID，系统自动生成"
    },
    "user_id": {
      "bsonType": "string",
      "description": "用户 ID，关联 uni-id-users 表",
      "foreignKey": "uni-id-users._id"
    },
    "title": {
      "bsonType": "string",
      "description": "游记标题（可选）",
      "maxLength": 100
    },
    "content": {
      "bsonType": "string",
      "description": "游记内容",
      "maxLength": 10000
    },
    "images": {
      "bsonType": "array",
      "description": "图片 URL 数组",
      "items": {
        "bsonType": "string"
      },
      "maxItems": 6
    },
    "location": {
      "bsonType": "object",
      "description": "位置信息",
      "properties": {
        "address": {
          "bsonType": "string",
          "description": "详细地址"
        },
        "latitude": {
          "bsonType": "double",
          "description": "纬度"
        },
        "longitude": {
          "bsonType": "double",
          "description": "经度"
        }
      }
    },
    "template": {
      "bsonType": "string",
      "description": "使用的模板 ID",
      "enum": ["literary", "humorous", "concise", "poetic"]
    },
    "created_at": {
      "bsonType": "timestamp",
      "description": "创建时间",
      "forceDefaultValue": {
        "$env": "now"
      }
    },
    "updated_at": {
      "bsonType": "timestamp",
      "description": "最后更新时间",
      "forceDefaultValue": {
        "$env": "now"
      }
    },
    "is_edited": {
      "bsonType": "bool",
      "description": "是否已编辑",
      "defaultValue": false
    },
    "edit_history": {
      "bsonType": "array",
      "description": "编辑历史记录",
      "items": {
        "bsonType": "object",
        "properties": {
          "content": {
            "bsonType": "string",
            "description": "编辑后的内容"
          },
          "edited_at": {
            "bsonType": "timestamp",
            "description": "编辑时间"
          }
        }
      }
    }
  }
}
```

**索引设计**:
- `user_id`: 普通索引，用于查询用户的所有游记
- `created_at`: 降序索引，用于按时间排序
- `user_id + created_at`: 复合索引，优化用户游记列表查询

#### error_logs 表

存储错误日志数据。

**表结构**:
```json
{
  "bsonType": "object",
  "required": ["error_type", "created_at"],
  "permission": {
    "read": false,
    "create": true,
    "update": false,
    "delete": false
  },
  "properties": {
    "_id": {
      "bsonType": "string",
      "description": "日志 ID，系统自动生成"
    },
    "user_id": {
      "bsonType": "string",
      "description": "用户 ID（可选）",
      "foreignKey": "uni-id-users._id"
    },
    "error_type": {
      "bsonType": "string",
      "description": "错误类型",
      "enum": ["NETWORK_TIMEOUT", "CLOUD_FUNCTION_ERROR", "AI_API_ERROR", "UNKNOWN_ERROR"]
    },
    "error_message": {
      "bsonType": "string",
      "description": "错误信息"
    },
    "error_stack": {
      "bsonType": "string",
      "description": "错误堆栈"
    },
    "context": {
      "bsonType": "object",
      "description": "错误上下文信息"
    },
    "created_at": {
      "bsonType": "timestamp",
      "description": "创建时间",
      "forceDefaultValue": {
        "$env": "now"
      }
    }
  }
}
```

**索引设计**:
- `created_at`: 降序索引，用于按时间查询日志
- `error_type`: 普通索引，用于按错误类型统计


## Correctness Properties

*属性（Property）是系统在所有有效执行中都应该保持为真的特征或行为——本质上是关于系统应该做什么的形式化陈述。属性是人类可读规范和机器可验证正确性保证之间的桥梁。*

基于需求文档中的验收标准，我们识别出以下可测试的正确性属性。这些属性将通过属性测试（Property-Based Testing）进行验证，确保系统在各种输入条件下都能正确运行。

### Property Reflection

在定义具体属性之前，我们需要识别并消除冗余属性：

**识别的潜在冗余**:
1. 属性 4.2（新游记同时保存到本地和云端）和属性 6.8（编辑后保存到本地和云端）可以合并为一个更通用的"数据持久化"属性
2. 属性 7.1（记录生成次数）、7.2（记录使用时长）、7.3（统计访问地点）可以合并为一个"统计数据累积"属性
3. 属性 8.2（云函数错误处理）、8.4（AI API错误处理）、8.5（未预期错误处理）可以合并为一个"错误处理"属性

**合并后的属性集**:
经过反思，我们将保留独立的属性以确保每个验收标准都有明确的测试覆盖，但会在实现时注意复用测试基础设施。

### Property 1: 后端请求统一使用云函数

*对于任意*需要后端服务的操作，系统都应该通过 uniCloud.callFunction 调用云函数，而不是使用其他后端服务。

**验证需求**: 1.5

### Property 2: 错误显示包含具体信息

*对于任意*生成过程中发生的错误，系统都应该显示包含具体错误信息的提示，而不是通用的"发生错误"消息。

**验证需求**: 2.5

### Property 3: 模板选择生成对应 Prompt

*对于任意*用户选择的模板，模板引擎都应该构建包含该模板特定风格指令的 AI prompt。

**验证需求**: 3.3

### Property 4: 模板选择持久化

*对于任意*用户选择的模板，系统都应该将其保存到本地存储，并在下次启动时作为默认选项。

**验证需求**: 3.4

### Property 5: 新游记双向保存

*对于任意*新生成的游记，同步服务都应该将其同时保存到本地存储和云数据库（如果用户已登录）。

**验证需求**: 4.2

### Property 6: 数据冲突以云端为准

*对于任意*本地存储和云数据库中不一致的游记数据，同步服务都应该以云数据库的版本为准进行合并。

**验证需求**: 4.4

### Property 7: 未同步游记自动上传

*对于任意*标记为未同步的本地游记，当用户登录后，同步服务都应该将其上传到云数据库。

**验证需求**: 4.6

### Property 8: 分享图片包含必要元素

*对于任意*游记，生成的分享图片都应该包含游记内容、图片和二维码这三个必要元素。

**验证需求**: 5.1

### Property 9: 分享图片包含水印

*对于任意*生成的分享图片，都应该在底部包含"由 AI 随行记生成"水印文字。

**验证需求**: 5.2

### Property 10: 分享图片包含有效二维码

*对于任意*生成的分享图片，其中的小程序码二维码都应该是有效的，扫码后能够跳转到对应的游记页面。

**验证需求**: 5.5

### Property 11: 长内容自动截取

*对于任意*超过 200 字的游记内容，分享生成器都应该自动截取前 200 字并在末尾添加省略号（...）。

**验证需求**: 5.7

### Property 12: 段落重新生成仅影响选中段落

*对于任意*用户选中的段落，重新生成操作都应该只修改该段落的内容，而不影响其他段落。

**验证需求**: 6.5

### Property 13: 编辑后双向保存

*对于任意*编辑后的游记，系统都应该将修改后的内容同时保存到本地存储和云数据库（如果用户已登录）。

**验证需求**: 6.8

### Property 14: 编辑历史记录保留

*对于任意*游记的编辑操作，系统都应该在 edit_history 数组中记录原始版本和修改版本。

**验证需求**: 6.9

### Property 15: 生成次数累积

*对于任意*游记生成操作，统计服务都应该将用户的游记生成次数增加 1。

**验证需求**: 7.1

### Property 16: 使用时长累积

*对于任意*用户使用时段，统计服务都应该将该时段的时长累加到用户的累计使用时长中。

**验证需求**: 7.2

### Property 17: 地点访问频率统计

*对于任意*游记集合，统计服务都应该能够正确计算每个地点的访问次数，并识别出访问最多的地点。

**验证需求**: 7.3

### Property 18: 足迹地图包含所有位置

*对于任意*有位置信息的游记，其位置都应该在足迹地图上显示为一个标记点。

**验证需求**: 7.5

### Property 19: 地图标记关联游记列表

*对于任意*地图上的标记点，点击后都应该显示该位置对应的所有游记列表。

**验证需求**: 7.6

### Property 20: 月度统计正确分组

*对于任意*游记集合，统计服务都应该能够按月份正确分组并计算每个月的游记生成数量。

**验证需求**: 7.7

### Property 21: 统计数据云端同步

*对于任意*统计数据的更新，系统都应该将更新后的数据同步到云数据库（如果用户已登录）。

**验证需求**: 7.8

### Property 22: 云函数错误友好提示

*对于任意*云函数调用失败的错误，系统都应该捕获该错误并显示用户友好的中文错误提示，而不是显示原始的技术错误信息。

**验证需求**: 8.2

### Property 23: AI API 错误中文提示

*对于任意*AI API 返回的错误代码，系统都应该将其解析并显示对应的中文错误提示。

**验证需求**: 8.4

### Property 24: 未预期错误记录日志

*对于任意*未预期的错误，系统都应该显示通用错误提示并将错误详情（包括堆栈信息）记录到错误日志中。

**验证需求**: 8.5

### Property 25: 错误日志云端上传

*对于任意*捕获的错误，系统都应该将错误日志上传到云数据库的 error_logs 表中。

**验证需求**: 8.6

### Property 26: 可重试错误显示重试按钮

*对于任意*标记为可重试的错误（如网络超时、云函数失败），系统都应该在错误提示中显示"重试"按钮。

**验证需求**: 8.7

## Error Handling

### 错误分类

系统中的错误按照来源和处理方式分为以下几类：

#### 1. 网络错误
- **超时错误**: 请求超过设定的超时时间（120秒）
- **连接失败**: 无法连接到服务器
- **网络中断**: 请求过程中网络断开

**处理策略**:
- 显示友好提示："网络连接超时，请检查网络设置"
- 提供重试按钮
- 自动切换到离线模式（使用本地存储）

#### 2. 云函数错误
- **调用失败**: uniCloud.callFunction 返回错误
- **参数错误**: 缺少必需参数或参数格式错误
- **权限错误**: 用户无权限调用该云函数

**处理策略**:
- 解析云函数返回的错误信息
- 显示中文错误提示
- 记录错误日志到云数据库
- 对于可重试的错误，提供重试按钮

#### 3. AI API 错误
- **API Key 无效**: 401 Unauthorized
- **配额超限**: 429 Too Many Requests
- **模型不可用**: 503 Service Unavailable
- **内容违规**: 400 Bad Request (content_policy_violation)

**处理策略**:
- 根据 HTTP 状态码和错误代码显示对应的中文提示
- 对于 401 错误，引导用户到设置页面配置 API Key
- 对于 429 错误，提示用户稍后重试
- 对于 503 错误，提示用户切换模型或稍后重试

#### 4. 数据同步错误
- **本地存储失败**: uni.setStorageSync 抛出异常
- **云数据库写入失败**: 数据库操作返回错误
- **数据冲突**: 本地和云端数据版本不一致

**处理策略**:
- 对于本地存储失败，提示用户清理存储空间
- 对于云数据库写入失败，标记数据为未同步，等待下次重试
- 对于数据冲突，以云端数据为准，保留本地数据作为备份

#### 5. 用户输入错误
- **缺少必要信息**: 未选择图片或未获取位置
- **输入格式错误**: 反馈文本过长或包含非法字符

**处理策略**:
- 在用户操作前进行前端验证
- 显示明确的错误提示，指导用户如何修正
- 禁用提交按钮直到输入有效

### 错误处理流程

```
用户操作
   │
   ▼
前端验证 ──失败──> 显示输入错误提示
   │
   │成功
   ▼
调用 API/云函数
   │
   ├──成功──> 处理响应数据
   │
   └──失败──> 错误分类
              │
              ├──网络错误──> 显示网络错误提示 + 重试按钮
              │
              ├──云函数错误──> 解析错误信息 + 记录日志 + 显示提示
              │
              ├──AI API错误──> 根据错误码显示对应提示
              │
              └──未知错误──> 显示通用错误提示 + 记录日志
```

### 错误信息映射表

| 错误类型 | 错误代码 | 用户提示 | 是否可重试 |
|---------|---------|---------|-----------|
| 网络超时 | NETWORK_TIMEOUT | 网络连接超时，请检查网络设置 | 是 |
| 云函数失败 | CLOUD_FUNCTION_ERROR | 服务暂时不可用，请稍后重试 | 是 |
| API Key 无效 | AI_API_401 | API Key 无效，请前往设置页面配置 | 否 |
| API 配额超限 | AI_API_429 | API 调用次数已达上限，请稍后重试 | 是 |
| AI 服务不可用 | AI_API_503 | AI 服务暂时不可用，请稍后重试 | 是 |
| 内容违规 | AI_API_CONTENT_POLICY | 内容不符合规范，请修改后重试 | 否 |
| 缺少参数 | MISSING_PARAMS | 缺少必要信息，请完善后重试 | 否 |
| 权限不足 | PERMISSION_DENIED | 权限不足，请登录后重试 | 否 |
| 存储空间不足 | STORAGE_FULL | 存储空间不足，请清理后重试 | 否 |
| 未知错误 | UNKNOWN_ERROR | 发生未知错误，请稍后重试 | 是 |

### 错误日志格式

所有错误都应该记录到云数据库的 error_logs 表中，格式如下：

```javascript
{
  user_id: string,           // 用户 ID（如果已登录）
  error_type: string,        // 错误类型代码
  error_message: string,     // 错误信息
  error_stack: string,       // 错误堆栈
  context: {                 // 错误上下文
    page: string,            // 发生错误的页面
    action: string,          // 触发错误的操作
    params: object,          // 相关参数
    timestamp: number        // 时间戳
  },
  created_at: timestamp      // 创建时间
}
```

## Testing Strategy

### 测试方法论

本项目采用**双重测试策略**，结合单元测试和属性测试，确保全面的测试覆盖：

1. **单元测试（Unit Tests）**: 验证特定示例、边缘情况和错误条件
2. **属性测试（Property-Based Tests）**: 验证通用属性在所有输入下都成立

这两种测试方法是互补的，缺一不可：
- 单元测试帮助我们捕获具体的、已知的错误场景
- 属性测试帮助我们发现未预期的边缘情况和输入组合

### 测试工具选择

#### 前端测试
- **测试框架**: Jest
- **属性测试库**: fast-check
- **UI 测试**: @vue/test-utils

#### 云函数测试
- **测试框架**: Jest
- **属性测试库**: fast-check
- **Mock 工具**: jest-mock

### 属性测试配置

所有属性测试必须遵循以下配置：

```javascript
// 最小迭代次数：100 次
fc.assert(
  fc.property(
    // 生成器定义
    fc.string(),
    // 属性验证
    (input) => {
      // 测试逻辑
    }
  ),
  { numRuns: 100 } // 最少 100 次迭代
)
```

每个属性测试必须包含标签注释，引用设计文档中的属性：

```javascript
/**
 * Feature: ai-travelnote-optimization
 * Property 3: 模板选择生成对应 Prompt
 * 
 * 对于任意用户选择的模板，模板引擎都应该构建包含该模板特定风格指令的 AI prompt。
 */
test('template selection generates corresponding prompt', () => {
  fc.assert(
    fc.property(
      fc.constantFrom('literary', 'humorous', 'concise', 'poetic'),
      fc.string(),
      (templateId, address) => {
        const prompt = templateEngine.buildPrompt(templateId, address)
        const template = TEMPLATES[templateId]
        return prompt.includes(template.prompt)
      }
    ),
    { numRuns: 100 }
  )
})
```

### 测试覆盖范围

#### 1. 模板引擎测试

**单元测试**:
- 测试每个模板都能生成有效的 prompt
- 测试默认模板是"文艺风"
- 测试 prompt 包含地点信息
- 测试反馈文本正确拼接到 prompt 中

**属性测试**:
- Property 3: 任意模板选择都生成对应的 prompt
- Property 4: 任意模板选择都能被正确保存和恢复

#### 2. 历史记录管理器测试

**单元测试**:
- 测试保存单条游记到本地
- 测试获取空历史记录
- 测试清空历史记录
- 测试历史记录最多保存 50 条

**属性测试**:
- Property 5: 任意新游记都同时保存到本地和云端
- Property 6: 任意数据冲突都以云端为准
- Property 7: 任意未同步游记都能自动上传

#### 3. 同步服务测试

**单元测试**:
- 测试未登录时仅使用本地存储
- 测试登录后自动同步
- 测试网络异常时的降级处理

**属性测试**:
- Property 5: 任意新游记都双向保存
- Property 6: 任意冲突都以云端为准
- Property 7: 任意未同步数据都能上传

#### 4. 分享生成器测试

**单元测试**:
- 测试生成包含所有必要元素的分享图片
- 测试水印位置和样式
- 测试二维码生成

**属性测试**:
- Property 8: 任意游记都生成包含必要元素的分享图片
- Property 9: 任意分享图片都包含水印
- Property 10: 任意分享图片都包含有效二维码
- Property 11: 任意超过 200 字的内容都被正确截取

#### 5. 编辑器测试

**单元测试**:
- 测试编辑标题和正文
- 测试插入表情符号
- 测试添加自定义标签

**属性测试**:
- Property 12: 任意段落重新生成只影响该段落
- Property 13: 任意编辑都双向保存
- Property 14: 任意编辑都记录历史版本

#### 6. 统计服务测试

**单元测试**:
- 测试初始统计数据为 0
- 测试单次生成增加计数
- 测试地图标记显示

**属性测试**:
- Property 15: 任意生成操作都增加计数
- Property 16: 任意使用时段都累积时长
- Property 17: 任意游记集合都能正确统计地点频率
- Property 18: 任意有位置的游记都在地图上显示
- Property 19: 任意地图标记都关联正确的游记列表
- Property 20: 任意游记集合都能按月正确分组
- Property 21: 任意统计数据都同步到云端

#### 7. 错误处理器测试

**单元测试**:
- 测试网络超时错误提示
- 测试 API Key 无效错误提示
- 测试未知错误的通用提示

**属性测试**:
- Property 2: 任意错误都显示具体信息
- Property 22: 任意云函数错误都显示友好提示
- Property 23: 任意 AI API 错误都显示中文提示
- Property 24: 任意未预期错误都记录日志
- Property 25: 任意错误都上传到云端
- Property 26: 任意可重试错误都显示重试按钮

### 测试数据生成器

为了支持属性测试，我们需要定义以下数据生成器：

```javascript
// 游记生成器
const noteGenerator = fc.record({
  id: fc.string(),
  time: fc.date().map(d => d.toLocaleString()),
  address: fc.string({ minLength: 1, maxLength: 100 }),
  content: fc.string({ minLength: 1, maxLength: 10000 }),
  cover: fc.webUrl(),
  template: fc.constantFrom('literary', 'humorous', 'concise', 'poetic'),
  synced: fc.boolean(),
  updated_at: fc.integer({ min: 0 })
})

// 模板 ID 生成器
const templateIdGenerator = fc.constantFrom('literary', 'humorous', 'concise', 'poetic')

// 地点信息生成器
const locationGenerator = fc.record({
  address: fc.string({ minLength: 1, maxLength: 200 }),
  latitude: fc.double({ min: -90, max: 90 }),
  longitude: fc.double({ min: -180, max: 180 })
})

// 错误类型生成器
const errorTypeGenerator = fc.constantFrom(
  'NETWORK_TIMEOUT',
  'CLOUD_FUNCTION_ERROR',
  'AI_API_ERROR',
  'MISSING_PARAMS',
  'PERMISSION_DENIED',
  'UNKNOWN_ERROR'
)

// 图片 URL 数组生成器
const imageUrlsGenerator = fc.array(fc.webUrl(), { minLength: 1, maxLength: 6 })

// 长文本生成器（用于测试截取）
const longTextGenerator = fc.string({ minLength: 201, maxLength: 1000 })
```

### 集成测试

除了单元测试和属性测试，还需要进行以下集成测试：

1. **端到端流程测试**:
   - 完整的游记生成流程：选择图片 → 获取位置 → 选择模板 → 生成游记 → 保存历史
   - 完整的同步流程：本地保存 → 登录 → 自动同步 → 云端验证
   - 完整的分享流程：生成游记 → 生成分享图片 → 保存到相册

2. **云函数集成测试**:
   - 测试 generate-note 云函数与 WeAPIs 的集成
   - 测试 sync-notes 云函数与云数据库的集成
   - 测试错误日志上传到云数据库

3. **离线模式测试**:
   - 测试网络断开时的降级处理
   - 测试网络恢复后的自动同步
   - 测试离线状态下的本地存储功能

### 测试执行策略

1. **开发阶段**: 每次代码提交前运行所有单元测试和属性测试
2. **集成阶段**: 每日运行完整的集成测试套件
3. **发布前**: 运行所有测试，包括端到端测试和性能测试
4. **生产监控**: 持续监控错误日志，及时发现和修复问题

### 测试覆盖率目标

- **代码覆盖率**: 至少 80%
- **分支覆盖率**: 至少 75%
- **属性测试覆盖**: 所有 26 个正确性属性都有对应的属性测试
- **单元测试覆盖**: 所有核心模块都有单元测试
