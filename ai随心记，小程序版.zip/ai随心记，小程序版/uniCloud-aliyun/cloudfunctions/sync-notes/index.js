'use strict';

/**
 * 游记同步云函数
 * 
 * 功能：处理游记的云端同步（上传、下载、合并）
 * 
 * @param {Object} event - 云函数事件参数
 * @param {string} event.action - 操作类型：upload（上传）、download（下载）、merge（合并）
 * @param {Array<Object>} event.notes - 游记数组（upload 操作必需）
 * 
 * @returns {Object} 返回结果
 * @returns {boolean} returns.ok - 是否成功
 * @returns {Array<Object>} returns.data - 返回的游记数据
 * @returns {string} returns.error - 错误代码（失败时）
 * @returns {string} returns.message - 错误消息（失败时）
 */
exports.main = async (event, context) => {
  console.log('[SyncNotes] 收到请求');
  console.log('[SyncNotes] 操作类型:', event.action);
  
  const { action, notes } = event;
  const db = uniCloud.database();
  const collection = db.collection('travel_notes');
  
  // 获取当前用户 ID
  const uid = context.CLIENTIP; // 临时使用 IP，实际应使用 uni-id 获取用户 ID
  // TODO: 集成 uni-id 后改为：const uid = context.auth.uid;
  
  if (!uid) {
    console.error('[SyncNotes] 用户未登录');
    return {
      ok: false,
      error: 'not_logged_in',
      message: '请先登录'
    };
  }
  
  try {
    // 根据操作类型分发处理
    switch (action) {
      case 'ping':
        // 健康检查
        console.log('[SyncNotes] Ping 检测');
        return {
          ok: true,
          message: '云端就绪',
          timestamp: Date.now()
        };
      
      case 'upload':
        return await handleUpload(collection, uid, notes);
      
      case 'download':
        return await handleDownload(collection, uid);
      
      case 'merge':
        return await handleMerge(collection, uid, notes);
      
      default:
        console.error('[SyncNotes] 未知操作类型:', action);
        return {
          ok: false,
          error: 'invalid_action',
          message: '无效的操作类型'
        };
    }
  } catch (error) {
    console.error('[SyncNotes] 处理失败:', error);
    return {
      ok: false,
      error: 'system_error',
      message: error.message || '系统错误'
    };
  }
};

/**
 * 处理上传操作
 * @param {Object} collection - 数据库集合
 * @param {string} uid - 用户 ID
 * @param {Array<Object>} notes - 游记数组
 * @returns {Promise<Object>} 处理结果
 */
async function handleUpload(collection, uid, notes) {
  console.log('[SyncNotes] 处理上传操作');
  
  if (!Array.isArray(notes) || notes.length === 0) {
    return {
      ok: false,
      error: 'invalid_notes',
      message: '游记数据无效'
    };
  }
  
  console.log('[SyncNotes] 上传游记数量:', notes.length);
  
  const uploadedNotes = [];
  
  // 逐个上传游记
  for (const note of notes) {
    try {
      // 构建数据库记录
      const record = {
        user_id: uid,
        title: note.address || '未命名游记',
        content: note.content || '',
        images: note.cover ? [note.cover] : [],
        location: {
          address: note.address || '',
          addressText: note.address || ''
        },
        template: note.template || 'literary',
        created_at: note.created_at || Date.now(),
        updated_at: Date.now(),
        is_edited: false,
        edit_history: []
      };
      
      // 插入数据库
      const res = await collection.add(record);
      
      console.log('[SyncNotes] 上传成功，ID:', res.id);
      
      uploadedNotes.push({
        ...note,
        _id: res.id,
        synced: true
      });
    } catch (error) {
      console.error('[SyncNotes] 上传单条游记失败:', error);
      // 继续处理下一条
    }
  }
  
  console.log('[SyncNotes] 上传完成，成功:', uploadedNotes.length);
  
  return {
    ok: true,
    data: uploadedNotes,
    count: uploadedNotes.length
  };
}

/**
 * 处理下载操作
 * @param {Object} collection - 数据库集合
 * @param {string} uid - 用户 ID
 * @returns {Promise<Object>} 处理结果
 */
async function handleDownload(collection, uid) {
  console.log('[SyncNotes] 处理下载操作');
  
  // 查询该用户的所有游记
  const res = await collection
    .where({
      user_id: uid
    })
    .orderBy('created_at', 'desc')
    .limit(100) // 最多返回 100 条
    .get();
  
  console.log('[SyncNotes] 查询到游记数量:', res.data.length);
  
  // 转换为客户端格式
  const notes = res.data.map(record => ({
    id: record._id,
    time: new Date(record.created_at).toLocaleString(),
    address: record.location?.addressText || record.title,
    content: record.content,
    cover: record.images && record.images.length > 0 ? record.images[0] : '',
    template: record.template,
    synced: true,
    created_at: record.created_at
  }));
  
  return {
    ok: true,
    data: notes
  };
}

/**
 * 处理合并操作
 * @param {Object} collection - 数据库集合
 * @param {string} uid - 用户 ID
 * @param {Array<Object>} localNotes - 本地游记数组
 * @returns {Promise<Object>} 处理结果
 */
async function handleMerge(collection, uid, localNotes) {
  console.log('[SyncNotes] 处理合并操作');
  
  // 先下载云端数据
  const downloadResult = await handleDownload(collection, uid);
  
  if (!downloadResult.ok) {
    return downloadResult;
  }
  
  const cloudNotes = downloadResult.data;
  
  // 找出本地独有的游记（未同步的）
  const cloudNoteIds = new Set(cloudNotes.map(n => n.id));
  const localOnlyNotes = (localNotes || []).filter(n => !cloudNoteIds.has(n.id) && !n.synced);
  
  console.log('[SyncNotes] 云端游记数量:', cloudNotes.length);
  console.log('[SyncNotes] 本地独有游记数量:', localOnlyNotes.length);
  
  // 上传本地独有的游记
  if (localOnlyNotes.length > 0) {
    const uploadResult = await handleUpload(collection, uid, localOnlyNotes);
    
    if (uploadResult.ok) {
      // 合并上传后的游记
      const mergedNotes = [...cloudNotes, ...uploadResult.data];
      
      // 按创建时间降序排序
      mergedNotes.sort((a, b) => {
        const timeA = a.created_at || new Date(a.time).getTime();
        const timeB = b.created_at || new Date(b.time).getTime();
        return timeB - timeA;
      });
      
      return {
        ok: true,
        data: mergedNotes
      };
    }
  }
  
  // 没有本地独有游记，直接返回云端数据
  return {
    ok: true,
    data: cloudNotes
  };
}
