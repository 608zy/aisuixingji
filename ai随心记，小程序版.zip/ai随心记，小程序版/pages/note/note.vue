<template>
  <view class="container">
    <view v-if="mode === 'webview'" class="webview-wrap">
      <web-view :src="webSrc"></web-view>
    </view>

    <view v-else class="fallback">
      <view class="card">
        <view class="head">
          <input v-if="isEditing" v-model="editTitle" class="title-input" placeholder="输入标题" />
          <text v-else class="title">{{ title }}</text>
          <text class="badge">微网页预览</text>
        </view>
        <image v-if="coverSrc" :src="coverSrc" mode="aspectFill" class="cover" />
        <view v-else class="cover placeholder">
          <text class="placeholder-text">AI 随行记</text>
        </view>
        <text class="meta">{{ address }}</text>
        
        <!-- 编辑模式下显示段落，每个段落可以重新生成 -->
        <view v-if="isEditing" class="paragraphs-edit">
          <view v-for="(para, index) in editParagraphs" :key="index" class="paragraph-item">
            <textarea v-model="editParagraphs[index]" class="paragraph-input" auto-height />
            <button class="paragraph-regen-btn" @click="regenerateParagraph(index)">🔄 重新生成</button>
          </view>
        </view>
        <textarea v-else-if="isEditing" v-model="editContent" class="content-input" placeholder="输入内容" auto-height />
        <text v-else class="content">{{ content }}</text>
        
        <!-- 编辑模式下的表情符号选择器 -->
        <view v-if="isEditing" class="emoji-picker">
          <text class="emoji-label">常用表情：</text>
          <view class="emoji-list">
            <text v-for="emoji in commonEmojis" :key="emoji" class="emoji-item" @click="insertEmoji(emoji)">{{ emoji }}</text>
          </view>
        </view>
        
        <!-- 标签显示 -->
        <view v-if="editTags.length > 0" class="tags">
          <view v-for="(tag, index) in editTags" :key="index" class="tag">
            <text>{{ tag }}</text>
            <text v-if="isEditing" class="tag-remove" @click="removeTag(index)">×</text>
          </view>
        </view>
        
        <!-- 编辑模式下的标签输入 -->
        <view v-if="isEditing" class="tag-input-wrap">
          <input v-model="newTag" class="tag-input" placeholder="添加标签（如 #美食）" @confirm="addTag" />
          <button class="tag-add-btn" @click="addTag">添加</button>
        </view>
      </view>
    </view>

    <view class="actions">
      <button v-if="!isEditing" class="btn" @click="toggleEdit">编辑</button>
      <button v-if="isEditing" class="btn" @click="cancelEdit">取消</button>
      <button v-if="isEditing" class="btn primary" @click="saveEdit">保存</button>
      <button v-if="!isEditing" class="btn" @click="saveShareImage">保存图片</button>
      <button v-if="!isEditing" class="btn" @click="shareNote">分享游记</button>
      <button v-if="!isEditing" class="btn primary" @click="copyHtml">复制 HTML</button>
    </view>
    
    <!-- Canvas 用于生成分享图片 -->
    <canvas canvas-id="shareCanvas" class="share-canvas"></canvas>
  </view>
</template>

<script>
import { ShareGenerator } from '@/utils/share-generator.js'
import { HistoryManager } from '@/utils/history-manager.js'

function escapeHtml(str) {
  // 部分安卓 WebView/调试基座不支持 String.prototype.replaceAll，这里用 replace + /g 兼容
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function buildHtml({ title, address, content, coverSrc }) {
  const safeTitle = escapeHtml(title)
  const safeAddress = escapeHtml(address)
  const safeContent = escapeHtml(content).replace(/\n/g, '<br/>')

  const cover = coverSrc
    ? `<img class="cover" src="${coverSrc}" alt="cover" />`
    : `<div class="cover placeholder">AI 随行记</div>`

  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title>${safeTitle}</title>
  <style>
    :root{--bg:#f5f5f5;--card:#fff;--text:#222;--muted:#6b7280;--border:#e5e7eb;}
    *{box-sizing:border-box}
    body{margin:0;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,"PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif}
    .wrap{max-width:720px;margin:0 auto;padding:16px}
    .card{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.06)}
    .head{padding:18px 18px 8px}
    .title{font-size:22px;font-weight:800;letter-spacing:.5px}
    .meta{margin-top:6px;color:var(--muted);font-size:13px;line-height:1.4}
    .cover{width:100%;height:240px;object-fit:cover;display:block;background:#ddd}
    .cover.placeholder{display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;background:linear-gradient(135deg,#ff6b00,#ffb703)}
    .body{padding:14px 18px 18px;font-size:16px;line-height:1.8}
    .badge{display:inline-block;margin-top:10px;padding:6px 10px;border-radius:999px;background:#eef2ff;color:#3730a3;font-size:12px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      ${cover}
      <div class="head">
        <div class="title">${safeTitle}</div>
        <div class="meta">${safeAddress}</div>
        <div class="badge">AI 随行记 · 微网页</div>
      </div>
      <div class="body">${safeContent}</div>
    </div>
  </div>
</body>
</html>`
}

export default {
  data() {
    return {
      mode: 'fallback',
      webSrc: '',
      html: '',
      title: 'AI 随行记',
      address: '',
      content: '',
      coverSrc: '',
      noteId: '',
      isEditing: false, // 编辑模式标志
      editTitle: '', // 编辑中的标题
      editContent: '', // 编辑中的内容
      editTags: [], // 编辑中的标签
      newTag: '', // 新标签输入
      commonEmojis: ['😊', '😂', '❤️', '👍', '🎉', '🌟', '🌈', '🌸', '🍀', '🎈', '🎁', '🎂', '🍕', '🍔', '🍰', '☕', '🌍', '✈️', '🏖️', '🗻', '🏰', '🎭', '🎨', '📷', '🎵', '🎸', '⚽', '🏀', '🎾', '🏊'],
      editParagraphs: [], // 编辑中的段落数组
      showParagraphMode: false // 是否显示段落编辑模式
    }
  },
  async onLoad(query) {
    try {
      let payload = null
      
      try {
        payload = uni.getStorageSync('temp_note_payload')
        if (payload) {
          uni.removeStorageSync('temp_note_payload')
        }
      } catch (e) {
        console.log('从本地存储读取失败，尝试从 URL 读取', e)
      }
      
      if (!payload && query.payload) {
        payload = JSON.parse(decodeURIComponent(query.payload))
      }
      
      if (!payload) {
        payload = {}
      }
      
      this.title = payload.title || 'AI 随行记'
      this.address = payload.address || ''
      this.content = payload.content || ''
      let rawCover = payload.coverSrc || ''
      this.coverSrc = rawCover
      this.noteId = payload.id || query.id || ''

      this.html = buildHtml({
        title: this.title,
        address: this.address,
        content: this.content,
        coverSrc: this.processPathForHtml(rawCover)
      })
    } catch (e) {
      console.error('加载页面数据失败', e)
      this.content = '加载失败：参数错误'
      this.html = buildHtml({ title: this.title, address: '', content: this.content, coverSrc: '' })
    }

    this.mode = 'fallback'
  },
  methods: {
    async saveShareImage() {
      try {
        uni.showLoading({ title: '生成中...' })
        
        const imagePath = await ShareGenerator.generateShareImage({
          id: this.noteId,
          title: this.title,
          content: this.content,
          cover: this.coverSrc,
          address: this.address
        })
        
        uni.hideLoading()
        await ShareGenerator.saveToAlbum(imagePath)
        
      } catch (error) {
        uni.hideLoading()
        console.error('保存分享图片失败:', error)
        uni.showToast({
          title: '保存失败: ' + error.message,
          icon: 'none'
        })
      }
    },
    processPathForHtml(path) {
      if (!path || path.startsWith('http') || path.startsWith('data:')) return path
      // eslint-disable-next-line no-undef
      if (typeof plus !== 'undefined' && plus.io) {
        // eslint-disable-next-line no-undef
        let abs = plus.io.convertLocalFileSystemURL(path)
        return abs.startsWith('file://') ? abs : 'file://' + abs
      }
      return path
    },
    async shareNote() {
      // eslint-disable-next-line no-undef
      if (typeof plus === 'undefined') {
        uni.showToast({ title: '当前平台不支持分享', icon: 'none' })
        return
      }

      uni.showActionSheet({
        itemList: ['分享图片到微信', '分享文字到微信', '复制文字'],
        success: async (res) => {
          if (res.tapIndex === 0) {
            try {
              uni.showLoading({ title: '生成中...' })
              
              const imagePath = await ShareGenerator.generateShareImage({
                id: this.noteId,
                title: this.title,
                content: this.content,
                cover: this.coverSrc,
                address: this.address
              })
              
              uni.hideLoading()
              
              uni.share({
                provider: 'weixin',
                scene: 'WXSceneSession',
                type: 2,
                imageUrl: imagePath,
                success: () => uni.showToast({ title: '分享成功' }),
                fail: (err) => {
                  console.error('分享失败：', err)
                  uni.showToast({ title: '分享失败', icon: 'none' })
                }
              })
            } catch (error) {
              uni.hideLoading()
              console.error('生成分享图片失败:', error)
              uni.showToast({ title: '生成失败', icon: 'none' })
            }
          } else if (res.tapIndex === 1) {
            const summary = this.content.slice(0, 50) + '...'
            uni.share({
              provider: 'weixin',
              scene: 'WXSceneSession',
              type: 1,
              summary: `${this.title}\n${this.address}\n\n${summary}`,
              success: () => uni.showToast({ title: '分享成功' }),
              fail: (err) => {
                console.error('分享失败：', err)
                uni.showModal({
                  title: '分享提示',
                  content: '分享失败，请使用"复制文字"功能。',
                  showCancel: false
                })
              }
            })
          } else if (res.tapIndex === 2) {
            await uni.setClipboardData({ data: `${this.title}\n${this.address}\n\n${this.content}` })
            uni.showToast({ title: '文字已复制' })
          }
        }
      })
    },
    writeHtmlToDoc() {
      return new Promise((resolve, reject) => {
        // eslint-disable-next-line no-undef
        plus.io.requestFileSystem(plus.io.PRIVATE_DOC, (fs) => {
          const filename = `ai-travelnote-${Date.now()}.html`
          fs.root.getFile(filename, { create: true }, (entry) => {
            entry.createWriter((writer) => {
              writer.onwrite = () => {
                resolve(entry.toURL())
              }
              writer.onerror = (err) => reject(err)
              writer.write(this.html)
            }, reject)
          }, reject)
        }, reject)
      })
    },
    async exportHtml() {
      try {
        // eslint-disable-next-line no-undef
        if (typeof plus === 'undefined' || !plus.io) {
          await uni.setClipboardData({ data: this.html })
          uni.showToast({ title: '已复制 HTML（当前平台不支持导出文件）', icon: 'none' })
          return
        }
        const fileUrl = await this.writeHtmlToDoc()
        uni.showModal({
          title: '导出成功',
          content: `已导出到本机文件：\n${fileUrl}\n\n提示：要"网页链接分享"，需要把该文件上传到公网托管。`,
          showCancel: false
        })
      } catch (e) {
        uni.showToast({ title: '导出失败', icon: 'none' })
      }
    },
    async copyHtml() {
      await uni.setClipboardData({ data: this.html })
      uni.showToast({ title: 'HTML 已复制', icon: 'success' })
    },
    toggleEdit() {
      this.isEditing = true
      this.editTitle = this.title
      this.editContent = this.content
      this.editTags = [...(this.tags || [])]
      
      // 将内容分割为段落
      this.editParagraphs = this.content.split('\n').filter(p => p.trim())
      this.showParagraphMode = true
    },
    cancelEdit() {
      this.isEditing = false
      this.editTitle = ''
      this.editContent = ''
      this.editTags = []
      this.newTag = ''
      this.editParagraphs = []
      this.showParagraphMode = false
    },
    async saveEdit() {
      try {
        if (!this.editTitle.trim()) {
          uni.showToast({ title: '标题不能为空', icon: 'none' })
          return
        }
        
        // 从段落数组重新组合内容
        const finalContent = this.showParagraphMode 
          ? this.editParagraphs.filter(p => p.trim()).join('\n\n')
          : this.editContent
        
        if (!finalContent.trim()) {
          uni.showToast({ title: '内容不能为空', icon: 'none' })
          return
        }
        
        uni.showLoading({ title: '保存中...' })
        
        // 更新当前显示的内容
        const oldTitle = this.title
        const oldContent = this.content
        this.title = this.editTitle
        this.content = finalContent
        this.tags = [...this.editTags]
        
        // 构建编辑历史记录
        const editHistory = {
          timestamp: Date.now(),
          changes: {
            title: { old: oldTitle, new: this.title },
            content: { old: oldContent, new: this.content }
          }
        }
        
        // 直接保存到本地存储（不使用 HistoryManager）
        try {
          const history = uni.getStorageSync('travel_history') || []
          
          // 查找是否已存在该记录
          const existingIndex = history.findIndex(h => h.id === this.noteId)
          
          const updatedNote = {
            id: this.noteId || Date.now().toString(),
            time: new Date().toLocaleString(),
            address: this.address || '未知地点',
            content: this.content,
            cover: this.coverSrc || '',
            template: 'literary',
            tags: this.tags || [],
            is_edited: true,
            edit_history: [editHistory],
            updated_at: Date.now(),
            synced: false
          }
          
          if (existingIndex >= 0) {
            // 更新现有记录
            history[existingIndex] = updatedNote
          } else {
            // 添加新记录
            history.unshift(updatedNote)
          }
          
          // 保存到本地存储
          uni.setStorageSync('travel_history', history.slice(0, 50))
          
          console.log('[Note] 保存成功，记录 ID:', updatedNote.id)
          
        } catch (storageError) {
          console.error('[Note] 保存到本地存储失败:', storageError)
          throw new Error('保存失败: ' + (storageError.message || '存储错误'))
        }
        
        uni.hideLoading()
        uni.showToast({ title: '保存成功', icon: 'success' })
        
        // 退出编辑模式
        this.isEditing = false
        this.editTitle = ''
        this.editContent = ''
        this.editTags = []
        this.editParagraphs = []
        this.showParagraphMode = false
        
        // 更新 HTML
        this.html = buildHtml({
          title: this.title,
          address: this.address,
          content: this.content,
          coverSrc: this.processPathForHtml(this.coverSrc)
        })
        
      } catch (error) {
        uni.hideLoading()
        console.error('保存编辑失败:', error)
        uni.showToast({ 
          title: '保存失败: ' + (error.message || '未知错误'), 
          icon: 'none',
          duration: 3000
        })
      }
    },
    addTag() {
      if (!this.newTag.trim()) {
        return
      }
      
      let tag = this.newTag.trim()
      // 自动添加 # 前缀
      if (!tag.startsWith('#')) {
        tag = '#' + tag
      }
      
      if (!this.editTags.includes(tag)) {
        this.editTags.push(tag)
      }
      
      this.newTag = ''
    },
    removeTag(index) {
      this.editTags.splice(index, 1)
    },
    insertEmoji(emoji) {
      this.editContent += emoji
    },
    async regenerateParagraph(index) {
      try {
        uni.showLoading({ title: '重新生成中...' })
        
        const paragraph = this.editParagraphs[index]
        const apiKey = 'sk-aHspgwR9u0YAFdHnlXMRmDEpT55Y7AYYRnL83IR3rao8qKLx'
        const baseUrl = 'https://vg.v1api.cc/v1'
        const model = uni.getStorageSync('weapis_model') || 'gpt-4o-mini'
        
        const messages = [
          {
            role: 'system',
            content: '你是一位优秀的旅行文案作家。请根据用户提供的段落内容，重新生成一段风格相似、主题一致的文案。只输出新段落内容，不要加标题或额外说明。'
          },
          {
            role: 'user',
            content: `地点：${this.address || '未知地点'}\n\n请重新生成以下段落，保持相似的风格和主题：\n${paragraph}`
          }
        ]
        
        const res = await new Promise((resolve, reject) => {
          uni.request({
            url: `${baseUrl}/chat/completions`,
            method: 'POST',
            header: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiKey}`
            },
            data: { model, messages, max_tokens: 800, temperature: 0.7, stream: false },
            timeout: 60000,
            success: (r) => resolve(r),
            fail: (err) => reject(new Error(err.errMsg || '网络请求失败'))
          })
        })
        
        uni.hideLoading()
        
        if (res.statusCode === 200 && res.data?.choices?.[0]?.message?.content) {
          this.editParagraphs[index] = res.data.choices[0].message.content.trim()
          uni.showToast({ title: '重新生成成功', icon: 'success' })
        } else {
          const errMsg = res.data?.error?.message || `请求失败 (${res.statusCode})`
          throw new Error(errMsg)
        }
        
      } catch (error) {
        uni.hideLoading()
        console.error('重新生成段落失败:', error)
        uni.showToast({ title: '重新生成失败: ' + (error.message || '未知错误'), icon: 'none' })
      }
    }
  }
}
</script>

<style scoped>
.container {
  min-height: 100vh;
  background: #f6f7fb;
}
.webview-wrap {
  height: calc(100vh - 120rpx);
}
.fallback {
  padding: 24rpx;
  padding-bottom: 160rpx;
}
.card {
  background: #fff;
  border-radius: 24rpx;
  overflow: hidden;
  border: 1rpx solid rgba(17, 24, 39, 0.06);
  box-shadow: 0 16rpx 40rpx rgba(17, 24, 39, 0.08);
}
.head {
  padding: 26rpx 28rpx 10rpx;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16rpx;
}
.title {
  display: block;
  font-size: 40rpx;
  font-weight: 800;
  color: #222;
}
.badge {
  padding: 10rpx 14rpx;
  font-size: 22rpx;
  border-radius: 999rpx;
  background: rgba(79, 70, 229, 0.10);
  color: #3730a3;
  border: 1rpx solid rgba(79, 70, 229, 0.16);
}
.meta {
  display: block;
  padding: 10rpx 28rpx 18rpx;
  font-size: 26rpx;
  color: #6b7280;
}
.cover {
  width: 100%;
  height: 360rpx;
  background: #ddd;
}
.cover.placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #ff6b00, #ffb703);
}
.placeholder-text {
  font-size: 44rpx;
  font-weight: 900;
  color: rgba(255, 255, 255, 0.95);
  letter-spacing: 1rpx;
}
.content {
  display: block;
  padding: 0 28rpx 28rpx;
  font-size: 30rpx;
  line-height: 1.8;
  color: #333;
  white-space: pre-wrap;
}
.actions {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  padding: 18rpx 24rpx calc(18rpx + env(safe-area-inset-bottom));
  display: flex;
  gap: 16rpx;
  background: rgba(246, 247, 251, 0.92);
  backdrop-filter: blur(8px);
  border-top: 1rpx solid rgba(17, 24, 39, 0.06);
}
.btn {
  flex: 1;
  height: 88rpx;
  line-height: 88rpx;
  border-radius: 24rpx;
  font-size: 30rpx;
  border: none;
  background: #fff;
  color: #333;
  font-weight: 800;
}
.primary {
  background: linear-gradient(135deg, #007aff, #4f46e5);
  color: #fff;
  box-shadow: 0 14rpx 30rpx rgba(79, 70, 229, 0.18);
}
.share-canvas {
  position: fixed;
  left: -9999rpx;
  top: -9999rpx;
  width: 750rpx;
  height: 1334rpx;
}
.title-input {
  flex: 1;
  font-size: 40rpx;
  font-weight: 800;
  color: #222;
  border: 2rpx solid #e5e7eb;
  border-radius: 8rpx;
  padding: 10rpx;
}
.content-input {
  display: block;
  width: 100%;
  min-height: 400rpx;
  padding: 0 28rpx 28rpx;
  font-size: 30rpx;
  line-height: 1.8;
  color: #333;
  border: 2rpx solid #e5e7eb;
  border-radius: 8rpx;
  box-sizing: border-box;
}
.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 12rpx;
  padding: 0 28rpx 20rpx;
}
.tag {
  display: inline-flex;
  align-items: center;
  gap: 8rpx;
  padding: 8rpx 16rpx;
  background: rgba(79, 70, 229, 0.10);
  color: #3730a3;
  border-radius: 999rpx;
  font-size: 24rpx;
}
.tag-remove {
  font-size: 32rpx;
  font-weight: bold;
  cursor: pointer;
}
.tag-input-wrap {
  display: flex;
  gap: 12rpx;
  padding: 0 28rpx 28rpx;
}
.tag-input {
  flex: 1;
  height: 64rpx;
  padding: 0 16rpx;
  border: 2rpx solid #e5e7eb;
  border-radius: 8rpx;
  font-size: 28rpx;
}
.tag-add-btn {
  height: 64rpx;
  padding: 0 24rpx;
  background: #4f46e5;
  color: #fff;
  border: none;
  border-radius: 8rpx;
  font-size: 28rpx;
}
.emoji-picker {
  padding: 20rpx 28rpx;
  border-top: 1rpx solid #e5e7eb;
}
.emoji-label {
  display: block;
  font-size: 26rpx;
  color: #6b7280;
  margin-bottom: 12rpx;
}
.emoji-list {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
}
.emoji-item {
  font-size: 48rpx;
  cursor: pointer;
}
.paragraphs-edit {
  padding: 20rpx 28rpx;
}
.paragraph-item {
  margin-bottom: 24rpx;
  border: 2rpx solid #e5e7eb;
  border-radius: 12rpx;
  padding: 16rpx;
  background: #f9fafb;
}
.paragraph-input {
  width: 100%;
  min-height: 120rpx;
  font-size: 30rpx;
  line-height: 1.8;
  color: #333;
  background: transparent;
  border: none;
  margin-bottom: 12rpx;
}
.paragraph-regen-btn {
  width: 100%;
  height: 64rpx;
  line-height: 64rpx;
  background: #4f46e5;
  color: #fff;
  border: none;
  border-radius: 8rpx;
  font-size: 26rpx;
  text-align: center;
}
</style>
