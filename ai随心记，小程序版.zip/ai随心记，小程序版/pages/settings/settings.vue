<template>
  <view class="wrap">
    <view class="card">
      <view class="title-row">
        <text class="title">模型设置</text>
      </view>
      <view style="margin-top: 16rpx;">
        <text class="label">AI 模型选择</text>
        <picker class="input" mode="selector" :range="modelList" :value="modelIndex" @change="onModelChange">
          <view class="picker-text">{{ modelList[modelIndex] }}</view>
        </picker>
        <view class="model-desc">
          <text class="desc-text">{{ modelDescriptions[modelIndex] }}</text>
        </view>
        <view class="row" style="margin-top: 16rpx;">
          <button class="btn primary" @click="saveModel">保存设置</button>
        </view>
      </view>
      <view class="tips">
        <text>不同模型的生成效果和速度略有差异，推荐使用 gpt-4o-mini。</text>
      </view>
    </view>

    <!-- 历史记录展示 -->
    <view class="card" style="margin-top: 24rpx;">
      <view class="title-row">
        <text class="title">本地历史记录</text>
        <text class="clear-btn" @click="clearHistory">清空</text>
      </view>
      <scroll-view scroll-y="true" class="history-list" v-if="history.length > 0">
        <view v-for="item in history" :key="item.id" class="history-item" @click="viewHistoryDetail(item)">
          <image v-if="item.cover" :src="item.cover" mode="aspectFill" class="history-cover"></image>
          <view class="history-info">
            <text class="history-addr">{{ item.address }}</text>
            <text class="history-time">{{ item.time }}</text>
            <text class="history-content">{{ item.content }}</text>
          </view>
        </view>
      </scroll-view>
      <view class="empty-tip" v-else>
        <text>暂无生成记录</text>
      </view>
    </view>
    
    <!-- 数据统计入口 -->
    <view class="card" style="margin-top: 24rpx;">
      <view class="title-row">
        <text class="title">数据统计</text>
      </view>
      <view class="menu-item" @click="goToStats">
        <text class="menu-text">查看统计数据</text>
        <text class="menu-arrow">›</text>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      modelList: ['gpt-4o-mini', 'gpt-4o', 'gpt-3.5-turbo'],
      modelDescriptions: [
        '推荐 - 速度快，效果好，性价比高',
        '高级 - 效果最好，速度较慢',
        '经济 - 速度快，效果一般'
      ],
      modelIndex: 0,
      history: []
    }
  },
  onShow() {
    this.loadHistory()
  },
  onLoad() {
    try {
      const model = uni.getStorageSync('weapis_model') || 'gpt-4o-mini'
      this.modelIndex = this.modelList.indexOf(model) >= 0 ? this.modelList.indexOf(model) : 0
    } catch (e) {}
  },
  methods: {
    loadHistory() {
      this.history = uni.getStorageSync('travel_history') || []
    },
    clearHistory() {
      uni.showModal({
        title: '提示',
        content: '确定要清空所有历史记录吗？',
        success: (res) => {
          if (res.confirm) {
            uni.removeStorageSync('travel_history')
            this.history = []
            uni.showToast({ title: '已清空', icon: 'success' })
          }
        }
      })
    },
    viewHistoryDetail(item) {
      const payload = {
        title: '历史游记',
        address: item.address,
        content: item.content,
        coverSrc: item.cover
      }
      try {
        uni.setStorageSync('temp_note_payload', payload)
        uni.navigateTo({
          url: '/pages/note/note'
        })
      } catch (e) {
        console.error('保存临时数据失败', e)
        uni.showToast({ title: '跳转失败，请重试', icon: 'none' })
      }
    },
    onModelChange(e) {
      this.modelIndex = e.detail.value
    },
    saveModel() {
      try {
        uni.setStorageSync('weapis_model', this.modelList[this.modelIndex])
        uni.showToast({ title: '保存成功', icon: 'success' })
      } catch (e) {
        uni.showToast({ title: '保存失败', icon: 'none' })
      }
    },
    goToStats() {
      uni.navigateTo({
        url: '/pages/stats/stats'
      })
    }
  }
}
</script>

<style scoped>
.wrap{padding:24rpx;background:#f6f7fb;min-height:100vh}
.card{background:#fff;border-radius:24rpx;border:1rpx solid rgba(17,24,39,.06);box-shadow:0 16rpx 40rpx rgba(17,24,39,.08);padding:24rpx}
.title-row{display:flex;justify-content:space-between;align-items:center}
.title{display:block;font-size:36rpx;font-weight:800;color:#111827}
.label{display:block;font-size:26rpx;color:#6b7280;margin-bottom:8rpx}
.input{width:100%;height:88rpx;line-height:88rpx;border-radius:18rpx;background:#f3f4f6;padding:0 18rpx;border:2rpx solid #e5e7eb;font-size:28rpx;color:#111827}
.row{display:flex;gap:16rpx;margin-top:18rpx}
.btn{flex:1;height:88rpx;line-height:88rpx;border-radius:24rpx;font-size:30rpx;border:none;font-weight:800}
.primary{background:linear-gradient(135deg,#007aff,#4f46e5);color:#fff;box-shadow:0 14rpx 30rpx rgba(79,70,229,.18)}
.outline{background:#fff;color:#111827;border:2rpx solid rgba(17,24,39,.12)}
.tips{margin-top:14rpx;color:#6b7280;font-size:26rpx}

.clear-btn {
  font-size: 24rpx;
  color: #ef4444;
  padding: 8rpx 20rpx;
  border: 1rpx solid #fee2e2;
  border-radius: 999rpx;
  background: #fef2f2;
}

.menu-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24rpx 0;
  border-top: 1rpx solid #f3f4f6;
}

.menu-text {
  font-size: 28rpx;
  color: #111827;
}

.menu-arrow {
  font-size: 48rpx;
  color: #9ca3af;
  font-weight: 300;
}

.history-list {
  margin-top: 20rpx;
  max-height: 800rpx;
}

.history-item {
  display: flex;
  gap: 20rpx;
  padding: 20rpx 0;
  border-bottom: 1rpx solid #f3f4f6;
}

.history-item:last-child {
  border-bottom: none;
}

.history-cover {
  width: 120rpx;
  height: 120rpx;
  border-radius: 12rpx;
  flex-shrink: 0;
  background: #f3f4f6;
}

.history-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4rpx;
  overflow: hidden;
}

.history-addr {
  font-size: 28rpx;
  font-weight: bold;
  color: #111827;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.history-time {
  font-size: 22rpx;
  color: #9ca3af;
}

.history-content {
  font-size: 24rpx;
  color: #4b5563;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
  line-height: 1.4;
}

.empty-tip {
  padding: 60rpx 0;
  text-align: center;
  color: #9ca3af;
  font-size: 28rpx;
}

.picker-text {
  height: 88rpx;
  line-height: 88rpx;
  font-size: 28rpx;
  color: #111827;
}

.model-desc {
  margin-top: 12rpx;
  padding: 16rpx;
  background: #f0f9ff;
  border-radius: 12rpx;
  border: 1rpx solid #bfdbfe;
}

.desc-text {
  font-size: 24rpx;
  color: #1e40af;
  line-height: 1.5;
}
</style>
