<template>
  <view class="wrap">
    <view class="card profile">
      <image class="avatar" :src="avatarUrl || defaultAvatar" mode="aspectFill" />
      <view class="profile-info">
        <text class="name">{{ displayName }}</text>
        <text class="sub">{{ isLoggedIn ? '已登录（可解锁同步等功能）' : '未登录（登录后可同步/跨设备恢复）' }}</text>
      </view>
      <view class="profile-actions">
        <button v-if="!isLoggedIn" class="btn primary" @click="goLogin">微信一键登录</button>
        <button v-else class="btn outline" @click="logout">退出登录</button>
      </view>
    </view>

    <view class="card">
      <view class="row">
        <text class="row-title">历史记录同步</text>
        <text class="badge" :class="cloudStatusClass">{{ isLoggedIn ? cloudStatusText : '需登录' }}</text>
      </view>
      <text class="desc">
        历史记录保存在本地（travel_history）{{ isLoggedIn ? '，可随时同步到云端或从云端恢复。' : '。登录后将支持同步到云端与跨设备恢复。' }}
      </text>
      <text v-if="cloudStatus === 'error' && isLoggedIn" class="error-hint">
        错误信息: {{ cloudError }}
      </text>
      <view class="row-actions">
        <button class="btn primary" :disabled="!isLoggedIn || cloudStatus !== 'ready'" @click="syncNow">立即同步</button>
        <button class="btn outline" :disabled="!isLoggedIn || cloudStatus !== 'ready'" @click="restoreFromCloud">从云端恢复</button>
      </view>
      <text v-if="!isLoggedIn" class="hint">提示：先登录即可解锁同步功能。</text>
      <text v-if="isLoggedIn && cloudStatus === 'error'" class="hint">提示：云函数接入失败，请检查云函数是否已上传并配置正确。</text>
    </view>

    <view class="card">
      <view class="row">
        <text class="row-title">快捷入口</text>
      </view>
      <view class="row-actions">
        <button class="btn outline" @click="goSettings">设置</button>
        <button class="btn outline" @click="goHome">回首页</button>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      defaultAvatar:
        'data:image/svg+xml;utf8,' +
        encodeURIComponent(
          `<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">
            <defs>
              <linearGradient id="g" x1="0" x2="1" y1="0" y2="1">
                <stop offset="0" stop-color="#4f46e5"/><stop offset="1" stop-color="#007aff"/>
              </linearGradient>
            </defs>
            <rect width="120" height="120" rx="60" fill="url(#g)"/>
            <circle cx="60" cy="48" r="18" fill="rgba(255,255,255,.92)"/>
            <path d="M24 102c8-18 24-28 36-28s28 10 36 28" fill="rgba(255,255,255,.92)"/>
          </svg>`
        ),
      cloudStatus: 'checking', // checking, ready, error
      cloudError: ''
    }
  },
  computed: {
    token() {
      return uni.getStorageSync('uni_id_token') || ''
    },
    isLoggedIn() {
      return !!this.token
    },
    userInfo() {
      // uni-id-pages/uni-id-clientdb 常见会写入该 key；若没有也不影响登录判定
      return uni.getStorageSync('uni_id_user_info') || null
    },
    displayName() {
      const u = this.userInfo || {}
      return u.nickName || u.nickname || u.username || '游客'
    },
    avatarUrl() {
      const u = this.userInfo || {}
      return u.avatarUrl || u.avatar || ''
    },
    cloudStatusText() {
      if (this.cloudStatus === 'checking') return '检测中...'
      if (this.cloudStatus === 'ready') return '云端就绪'
      return '接入失败'
    },
    cloudStatusClass() {
      if (this.cloudStatus === 'ready') return 'ok'
      if (this.cloudStatus === 'error') return 'error'
      return ''
    }
  },
  onShow() {
    // 进入页面即刷新一次显示
    this.refresh()
    // 检测云函数状态
    if (this.isLoggedIn) {
      this.checkCloudStatus()
    }
  },
  methods: {
    refresh() {
      // 目前基于本地 token/userInfo 显示即可
      // 后续接入 uni-id-pages 后，你也可以在这里调用 getCurrentUserInfo 做一次兜底刷新
      this.$forceUpdate()
    },
    async checkCloudStatus() {
      try {
        console.log('[CloudCheck] 开始检测云函数状态...')
        this.cloudStatus = 'checking'
        
        // 调用云函数测试连接
        const res = await uniCloud.callFunction({
          name: 'sync-notes',
          data: {
            action: 'ping' // 添加一个 ping 操作用于测试
          },
          timeout: 10000 // 10秒超时
        })
        
        console.log('[CloudCheck] 云函数响应:', res)
        
        if (res.result) {
          this.cloudStatus = 'ready'
          this.cloudError = ''
          console.log('[CloudCheck] 云端就绪')
        } else {
          throw new Error('云函数返回异常')
        }
      } catch (error) {
        console.error('[CloudCheck] 云函数检测失败:', error)
        this.cloudStatus = 'error'
        this.cloudError = error.message || '连接失败'
      }
    },
    async goLogin() {
      // 这里直接跳 uni-id-pages 的登录页（你安装 uni-id-pages 后即可用）
      const candidates = [
        '/uni_modules/uni-id-pages/pages/login/login-withoutpwd',
        '/uni_modules/uni-id-pages/pages/login/login-withpwd',
        '/uni_modules/uni-id-pages/pages/login/login'
      ]

      for (const url of candidates) {
        try {
          await new Promise((resolve, reject) => {
            uni.navigateTo({
              url,
              success: resolve,
              fail: reject
            })
          })
          return
        } catch (e) {}
      }

      uni.showModal({
        title: '缺少登录模块',
        content:
          '当前项目未安装 uni-id-pages（或路由未加入 pages.json）。请在 HBuilderX 插件市场安装 uni-id-pages，然后重新运行。需要的话我也可以继续把云端 uni-id 配置与同步云函数补齐。',
        showCancel: false
      })
    },
    logout() {
      // 最小化退出：清 token + 用户信息
      const keysToRemove = [
        'uni_id_token',
        'uni_id_token_expired',
        'uni_id_refresh_token',
        'uni_id_user_info'
      ]
      keysToRemove.forEach((k) => {
        try {
          uni.removeStorageSync(k)
        } catch (e) {}
      })
      uni.showToast({ title: '已退出', icon: 'success' })
      this.refresh()
    },
    async syncNow() {
      try {
        uni.showLoading({ title: '正在同步...' })
        
        // 获取本地历史记录
        const localNotes = uni.getStorageSync('travel_history') || []
        
        if (localNotes.length === 0) {
          uni.hideLoading()
          uni.showToast({ title: '暂无数据需要同步', icon: 'none' })
          return
        }
        
        // 调用云函数同步
        const res = await uniCloud.callFunction({
          name: 'sync-notes',
          data: {
            action: 'upload',
            notes: localNotes
          }
        })
        
        uni.hideLoading()
        
        if (res.result && res.result.ok) {
          uni.showToast({
            title: `同步成功，共 ${res.result.count || localNotes.length} 条`,
            icon: 'success'
          })
        } else {
          throw new Error(res.result?.message || '同步失败')
        }
      } catch (error) {
        uni.hideLoading()
        console.error('同步失败:', error)
        uni.showToast({
          title: '同步失败: ' + (error.message || '未知错误'),
          icon: 'none',
          duration: 3000
        })
      }
    },
    async restoreFromCloud() {
      try {
        uni.showLoading({ title: '正在恢复...' })
        
        // 调用云函数下载
        const res = await uniCloud.callFunction({
          name: 'sync-notes',
          data: {
            action: 'download'
          }
        })
        
        if (res.result && res.result.ok) {
          const cloudNotes = res.result.data || []
          
          if (cloudNotes.length === 0) {
            uni.hideLoading()
            uni.showToast({ title: '云端暂无数据', icon: 'none' })
            return
          }
          
          // 合并到本地
          const localNotes = uni.getStorageSync('travel_history') || []
          const mergedNotes = [...cloudNotes]
          
          // 去重：以云端数据为准，本地独有的也保留
          localNotes.forEach(localNote => {
            const exists = cloudNotes.some(cloudNote => 
              cloudNote.id === localNote.id || 
              (cloudNote.address === localNote.address && 
               cloudNote.content === localNote.content &&
               Math.abs((cloudNote.timestamp || 0) - (localNote.timestamp || 0)) < 1000)
            )
            if (!exists) {
              mergedNotes.push(localNote)
            }
          })
          
          // 保存到本地
          uni.setStorageSync('travel_history', mergedNotes)
          
          uni.hideLoading()
          uni.showToast({
            title: `恢复成功，共 ${mergedNotes.length} 条`,
            icon: 'success'
          })
        } else {
          throw new Error(res.result?.message || '恢复失败')
        }
      } catch (error) {
        uni.hideLoading()
        console.error('恢复失败:', error)
        uni.showToast({
          title: '恢复失败: ' + (error.message || '未知错误'),
          icon: 'none',
          duration: 3000
        })
      }
    },
    goSettings() {
      uni.navigateTo({ url: '/pages/settings/settings' })
    },
    goHome() {
      // 项目未配置 tabBar，不能用 switchTab
      uni.reLaunch({ url: '/pages/index/index' })
    }
  }
}
</script>

<style scoped>
.wrap{padding:24rpx;background:#f6f7fb;min-height:100vh}
.card{background:#fff;border-radius:24rpx;border:1rpx solid rgba(17,24,39,.06);box-shadow:0 16rpx 40rpx rgba(17,24,39,.08);padding:24rpx}
.profile{display:flex;gap:18rpx;align-items:center}
.avatar{width:112rpx;height:112rpx;border-radius:999rpx;background:#f3f4f6;flex-shrink:0}
.profile-info{flex:1;min-width:0}
.name{display:block;font-size:34rpx;font-weight:900;color:#111827;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sub{display:block;margin-top:6rpx;font-size:24rpx;color:#6b7280}
.profile-actions{display:flex;flex-direction:column;gap:12rpx;flex-shrink:0}

.row{display:flex;justify-content:space-between;align-items:center}
.row-title{font-size:30rpx;font-weight:900;color:#111827}
.badge{font-size:22rpx;padding:6rpx 14rpx;border-radius:999rpx;border:1rpx solid #e5e7eb;background:#f3f4f6;color:#6b7280}
.badge.ok{border-color:#bbf7d0;background:#ecfdf5;color:#047857}
.badge.error{border-color:#fecaca;background:#fef2f2;color:#dc2626}
.desc{display:block;margin-top:12rpx;font-size:26rpx;color:#4b5563;line-height:1.5}
.error-hint{display:block;margin-top:8rpx;font-size:24rpx;color:#dc2626;background:#fef2f2;padding:12rpx;border-radius:8rpx;border:1rpx solid #fecaca}
.hint{display:block;margin-top:10rpx;font-size:24rpx;color:#9ca3af}

.row-actions{display:flex;gap:16rpx;margin-top:16rpx}
.btn{height:80rpx;line-height:80rpx;border-radius:20rpx;font-size:28rpx;border:none;font-weight:900;padding:0 18rpx}
.primary{background:linear-gradient(135deg,#007aff,#4f46e5);color:#fff;box-shadow:0 14rpx 30rpx rgba(79,70,229,.18)}
.outline{background:#fff;color:#111827;border:2rpx solid rgba(17,24,39,.12)}
.btn[disabled]{opacity:.45}
</style>
