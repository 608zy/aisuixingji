// 分享图片生成器
/**
 * 分享生成器类
 * 负责生成包含游记内容、图片和二维码的分享图片
 */
export class ShareGenerator {
  /**
   * 生成分享图片
   * @param {Object} note - 游记对象
   * @param {string} note.title - 标题
   * @param {string} note.content - 内容
   * @param {string} note.cover - 封面图片 URL
   * @param {string} note.address - 地点
   * @returns {Promise<string>} 生成的图片临时路径
   */
  static async generateShareImage(note) {
    return new Promise(async (resolve, reject) => {
      try {
        console.log('[ShareGenerator] 开始生成分享图片');
        
        // 截取内容（最多150字）
        const truncatedContent = this.truncateContent(note.content, 150);
        
        // 创建 Canvas 上下文
        const ctx = uni.createCanvasContext('shareCanvas');
        
        // 设置画布尺寸（单位：px）
        const canvasWidth = 750;
        const canvasHeight = 1334;
        
        // 绘制白色背景
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        
        // 绘制封面图片（如果有）
        if (note.cover) {
          try {
            // 绘制封面图片，填充整个画布
            await this.drawImage(ctx, note.cover, 0, 0, canvasWidth, canvasHeight);
            
            // 绘制半透明遮罩（深色渐变，从上到下）
            const gradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
            gradient.addColorStop(0, 'rgba(0, 0, 0, 0.6)');
            gradient.addColorStop(0.5, 'rgba(0, 0, 0, 0.4)');
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0.7)');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvasWidth, canvasHeight);
            
          } catch (imgError) {
            console.warn('[ShareGenerator] 绘制封面失败:', imgError);
            // 使用纯色背景
            ctx.fillStyle = '#1f2937';
            ctx.fillRect(0, 0, canvasWidth, canvasHeight);
          }
        } else {
          // 没有封面，使用渐变背景
          const gradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
          gradient.addColorStop(0, '#1e3a8a');
          gradient.addColorStop(1, '#312e81');
          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        }
        
        // 设置文字阴影，增强可读性
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 10;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
        
        let currentY = 100;
        
        // 绘制标题（浅蓝色，悬浮效果）
        ctx.fillStyle = '#93c5fd'; // 浅蓝色
        ctx.font = 'bold 48px sans-serif';
        ctx.textBaseline = 'top';
        const title = note.title || note.address || 'AI 随行记';
        this.drawWrappedText(ctx, title, 50, currentY, canvasWidth - 100, 60, 2);
        currentY += 140;
        
        // 绘制地点（更浅的蓝色）
        if (note.address) {
          ctx.fillStyle = '#bfdbfe'; // 更浅的蓝色
          ctx.font = '32px sans-serif';
          ctx.fillText('📍 ' + note.address, 50, currentY);
          currentY += 80;
        }
        
        // 绘制内容（白色，半透明）
        ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
        ctx.font = '30px sans-serif';
        const contentLines = this.drawWrappedText(ctx, truncatedContent, 50, currentY, canvasWidth - 100, 50, 12);
        currentY += contentLines * 50 + 100;
        
        // 重置阴影
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;
        
        // 绘制底部水印和二维码区域
        const footerY = canvasHeight - 180;
        
        // 绘制底部半透明背景条
        ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.fillRect(0, footerY, canvasWidth, 180);
        
        // 绘制水印
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.font = '28px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('由 AI 随行记生成', canvasWidth / 2, footerY + 90);
        ctx.textAlign = 'left'; // 重置对齐方式
        
        // 绘制小程序码（如果有）
        if (note.id) {
          try {
            await this.drawQRCode(ctx, note.id, canvasWidth, footerY);
          } catch (qrError) {
            console.warn('[ShareGenerator] 绘制小程序码失败:', qrError);
          }
        }
        
        // 绘制到画布
        ctx.draw(false, async () => {
          try {
            // 延长等待时间，确保所有绘制操作完成
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // 导出图片
            const tempFilePath = await this.canvasToTempFilePath('shareCanvas', canvasWidth, canvasHeight);
            console.log('[ShareGenerator] 分享图片生成成功:', tempFilePath);
            resolve(tempFilePath);
          } catch (error) {
            console.error('[ShareGenerator] Canvas 导出失败:', error);
            reject(error);
          }
        });
        
      } catch (error) {
        console.error('[ShareGenerator] 生成分享图片失败:', error);
        reject(error);
      }
    });
  }
  
  /**
   * 绘制自动换行文本
   * @param {Object} ctx - Canvas 上下文
   * @param {string} text - 文本内容
   * @param {number} x - X 坐标
   * @param {number} y - Y 坐标
   * @param {number} maxWidth - 最大宽度
   * @param {number} lineHeight - 行高
   * @param {number} maxLines - 最大行数
   * @returns {number} 实际绘制的行数
   */
  static drawWrappedText(ctx, text, x, y, maxWidth, lineHeight, maxLines = 999) {
    if (!text) return 0;
    
    const chars = text.split('');
    let line = '';
    let lineCount = 0;
    let currentY = y;
    
    for (let i = 0; i < chars.length; i++) {
      const testLine = line + chars[i];
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      
      if (testWidth > maxWidth && line !== '') {
        // 绘制当前行
        ctx.fillText(line, x, currentY);
        line = chars[i];
        currentY += lineHeight;
        lineCount++;
        
        if (lineCount >= maxLines) {
          // 达到最大行数，添加省略号
          if (i < chars.length - 1) {
            ctx.fillText(line + '...', x, currentY);
            lineCount++;
          }
          break;
        }
      } else {
        line = testLine;
      }
    }
    
    // 绘制最后一行
    if (line && lineCount < maxLines) {
      ctx.fillText(line, x, currentY);
      lineCount++;
    }
    
    return lineCount;
  }
  
  /**
   * 截取内容
   * @param {string} content - 原始内容
   * @param {number} maxLength - 最大长度
   * @returns {string} 截取后的内容
   */
  static truncateContent(content, maxLength = 200) {
    if (!content) return '';
    
    if (content.length <= maxLength) {
      return content;
    }
    
    return content.substring(0, maxLength) + '...';
  }
  
  /**
   * 绘制图片
   * @param {Object} ctx - Canvas 上下文
   * @param {string} imagePath - 图片路径
   * @param {number} x - X 坐标
   * @param {number} y - Y 坐标
   * @param {number} width - 宽度
   * @param {number} height - 高度
   * @returns {Promise<void>}
   */
  static async drawImage(ctx, imagePath, x, y, width, height) {
    return new Promise((resolve, reject) => {
      // 在微信小程序中，需要先获取图片信息确保图片已加载
      uni.getImageInfo({
        src: imagePath,
        success: (info) => {
          console.log('[ShareGenerator] 图片信息获取成功:', info.width, 'x', info.height);
          // 图片加载成功后再绘制
          ctx.drawImage(imagePath, x, y, width, height);
          // 等待一小段时间确保绘制完成
          setTimeout(() => {
            resolve();
          }, 100);
        },
        fail: (error) => {
          console.error('[ShareGenerator] 获取图片信息失败:', error);
          reject(error);
        }
      });
    });
  }
  
  /**
   * 绘制多行文本
   * @param {Object} ctx - Canvas 上下文
   * @param {string} text - 文本内容
   * @param {number} x - X 坐标
   * @param {number} y - Y 坐标
   * @param {number} maxWidth - 最大宽度
   * @param {number} lineHeight - 行高
   */
  static drawMultiLineText(ctx, text, x, y, maxWidth, lineHeight) {
    const lines = this.splitTextToLines(text, maxWidth);
    
    lines.forEach((line, index) => {
      ctx.fillText(line, x, y + index * lineHeight);
    });
  }
  
  /**
   * 将文本分割为多行
   * @param {string} text - 文本内容
   * @param {number} maxWidth - 最大宽度
   * @returns {Array<string>} 文本行数组
   */
  static splitTextToLines(text, maxWidth) {
    // 简化实现：按字符数分割
    const charsPerLine = Math.floor(maxWidth / 32); // 假设每个字符32px
    const lines = [];
    
    for (let i = 0; i < text.length; i += charsPerLine) {
      lines.push(text.substring(i, i + charsPerLine));
    }
    
    return lines;
  }
  
  /**
   * 绘制水印
   * @param {Object} ctx - Canvas 上下文
   * @param {number} canvasWidth - 画布宽度
   * @param {number} canvasHeight - 画布高度
   * @returns {Promise<void>}
   */
  static async drawWatermark(ctx, canvasWidth, canvasHeight) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.font = '24px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('由 AI 随行记生成', canvasWidth / 2, canvasHeight - 40);
    ctx.textAlign = 'left'; // 重置对齐方式
  }
  
  /**
   * 绘制二维码
   * @param {Object} ctx - Canvas 上下文
   * @param {string} noteId - 游记 ID
   * @param {number} canvasWidth - 画布宽度
   * @param {number} canvasHeight - 画布高度
   * @returns {Promise<void>}
   */
  static async drawQRCode(ctx, noteId, canvasWidth, canvasHeight) {
    try {
      console.log('[ShareGenerator] 生成小程序码');
      
      // 调用云函数生成小程序码
      const qrCodePath = await this.generateMiniProgramCode(noteId);
      
      if (qrCodePath) {
        // 绘制小程序码到右下角
        const qrSize = 160;
        const padding = 40;
        await this.drawImage(
          ctx, 
          qrCodePath, 
          canvasWidth - qrSize - padding, 
          canvasHeight - qrSize - padding - 80, // 留出水印空间
          qrSize, 
          qrSize
        );
      }
    } catch (error) {
      console.error('[ShareGenerator] 绘制二维码失败:', error);
      // 不抛出错误，允许继续生成分享图片
    }
  }
  
  /**
   * 生成小程序码
   * @param {string} noteId - 游记 ID
   * @returns {Promise<string>} 小程序码图片路径
   */
  static async generateMiniProgramCode(noteId) {
    try {
      const result = await uniCloud.callFunction({
        name: 'generate-qrcode',
        data: {
          noteId: noteId,
          page: 'pages/note/note'
        }
      });
      
      if (result.result && result.result.success) {
        return result.result.qrCodeUrl;
      } else {
        throw new Error(result.result?.message || '生成小程序码失败');
      }
    } catch (error) {
      console.error('[ShareGenerator] 生成小程序码失败:', error);
      throw error;
    }
  }
  
  /**
   * Canvas 转临时文件
   * @param {string} canvasId - Canvas ID
   * @param {number} width - 宽度
   * @param {number} height - 高度
   * @returns {Promise<string>} 临时文件路径
   */
  static canvasToTempFilePath(canvasId, width, height) {
    return new Promise((resolve, reject) => {
      uni.canvasToTempFilePath({
        canvasId: canvasId,
        width: width,
        height: height,
        destWidth: width,
        destHeight: height,
        success: (res) => {
          resolve(res.tempFilePath);
        },
        fail: (error) => {
          reject(error);
        }
      });
    });
  }
  
  /**
   * 保存图片到相册
   * @param {string|Array} tempFilePath - 临时文件路径（字符串或包含字符串的数组）
   * @returns {Promise<void>}
   */
  static async saveToAlbum(tempFilePath) {
    try {
      console.log('[ShareGenerator] 保存图片到相册, 参数类型:', typeof tempFilePath, tempFilePath);
      
      // 处理参数：如果是数组，取第一个元素
      let filePath = tempFilePath
      if (Array.isArray(tempFilePath)) {
        filePath = tempFilePath[0]
      }
      
      // 确保是字符串
      if (typeof filePath !== 'string') {
        throw new Error('图片路径必须是字符串')
      }
      
      // 请求相册权限
      const authResult = await this.requestAlbumAuth();
      
      if (!authResult) {
        throw new Error('用户拒绝授权访问相册');
      }
      
      // 保存到相册
      await uni.saveImageToPhotosAlbum({
        filePath: filePath
      });
      
      uni.showToast({
        title: '已保存到相册',
        icon: 'success'
      });
      
      console.log('[ShareGenerator] 保存成功');
    } catch (error) {
      console.error('[ShareGenerator] 保存到相册失败:', error);
      
      uni.showToast({
        title: '保存失败: ' + (error.message || '未知错误'),
        icon: 'none',
        duration: 3000
      });
      
      throw error;
    }
  }
  
  /**
   * 请求相册权限
   * @returns {Promise<boolean>} 是否授权
   */
  static async requestAlbumAuth() {
    return new Promise((resolve) => {
      uni.getSetting({
        success: (res) => {
          if (res.authSetting['scope.writePhotosAlbum']) {
            // 已授权
            resolve(true);
          } else {
            // 请求授权
            uni.authorize({
              scope: 'scope.writePhotosAlbum',
              success: () => {
                resolve(true);
              },
              fail: () => {
                // 授权失败，引导用户打开设置
                uni.showModal({
                  title: '提示',
                  content: '需要您授权保存图片到相册',
                  confirmText: '去设置',
                  success: (modalRes) => {
                    if (modalRes.confirm) {
                      uni.openSetting();
                    }
                    resolve(false);
                  }
                });
              }
            });
          }
        }
      });
    });
  }
}

/**
 * 快捷生成分享图片函数
 * @param {Object} note - 游记对象
 * @returns {Promise<string>} 图片路径
 */
export async function generateShareImage(note) {
  return await ShareGenerator.generateShareImage(note);
}

/**
 * 快捷保存到相册函数
 * @param {string} imagePath - 图片路径
 * @returns {Promise<void>}
 */
export async function saveToAlbum(imagePath) {
  return await ShareGenerator.saveToAlbum(imagePath);
}
