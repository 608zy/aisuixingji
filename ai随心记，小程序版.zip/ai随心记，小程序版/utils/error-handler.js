// 统一错误处理模块
import { ERROR_TYPES } from './constants.js'

/**
 * 错误处理器类
 */
export class ErrorHandler {
  /**
   * 处理错误
   * @param {Error|Object} error - 错误对象
   * @param {Object} context - 错误上下文
   * @returns {Object} 处理后的错误信息
   */
  static handle(error, context = {}) {
    console.error('[ErrorHandler] 处理错误:', error, context);
    
    let errorInfo = null;
    
    // 根据错误类型进行分类处理
    if (error.code) {
      // 已知错误类型
      errorInfo = ERROR_TYPES[error.code] || ERROR_TYPES.UNKNOWN_ERROR;
    } else if (error.message) {
      // 根据错误消息判断类型
      if (error.message.includes('timeout') || error.message.includes('超时')) {
        errorInfo = ERROR_TYPES.NETWORK_TIMEOUT;
      } else if (error.message.includes('云函数') || error.message.includes('cloud function')) {
        errorInfo = ERROR_TYPES.CLOUD_FUNCTION_ERROR;
      } else if (error.message.includes('API') || error.message.includes('401') || error.message.includes('403')) {
        errorInfo = ERROR_TYPES.AI_API_ERROR;
      } else if (error.message.includes('缺少') || error.message.includes('missing')) {
        errorInfo = ERROR_TYPES.MISSING_PARAMS;
      } else if (error.message.includes('权限') || error.message.includes('permission')) {
        errorInfo = ERROR_TYPES.PERMISSION_DENIED;
      } else {
        errorInfo = ERROR_TYPES.UNKNOWN_ERROR;
      }
    } else {
      errorInfo = ERROR_TYPES.UNKNOWN_ERROR;
    }
    
    return {
      ...errorInfo,
      originalError: error,
      context
    };
  }
  
  /**
   * 显示错误提示
   * @param {Object} errorInfo - 错误信息
   * @param {boolean} showRetry - 是否显示重试按钮
   */
  static showError(errorInfo, showRetry = false) {
    const message = errorInfo.message || '发生未知错误';
    
    if (showRetry && errorInfo.retry) {
      // 显示带重试按钮的模态框
      uni.showModal({
        title: '提示',
        content: message,
        confirmText: '重试',
        cancelText: '取消',
        success: (res) => {
          if (res.confirm) {
            // 触发重试事件（由调用方处理）
            uni.$emit('error-retry', errorInfo);
          }
        }
      });
    } else {
      // 显示普通提示
      uni.showToast({
        title: message,
        icon: 'none',
        duration: 3000
      });
    }
  }
  
  /**
   * 记录错误日志
   * @param {Error|Object} error - 错误对象
   * @param {Object} context - 错误上下文
   * @returns {Promise<void>}
   */
  static async logError(error, context = {}) {
    try {
      const errorInfo = this.handle(error, context);
      
      // 构建错误日志数据
      const logData = {
        error_type: errorInfo.code,
        error_message: errorInfo.message,
        error_stack: error.stack || '',
        context: {
          page: context.page || '',
          action: context.action || '',
          params: context.params || {},
          timestamp: Date.now()
        }
      };
      
      console.log('[ErrorHandler] 记录错误日志:', logData);
      
      // 调用云函数记录日志（暂时注释，等云函数创建后启用）
      // await uniCloud.callFunction({
      //   name: 'log-error',
      //   data: logData
      // });
      
    } catch (err) {
      console.error('[ErrorHandler] 记录错误日志失败:', err);
    }
  }
  
  /**
   * 处理并显示错误
   * @param {Error|Object} error - 错误对象
   * @param {Object} context - 错误上下文
   * @param {boolean} showRetry - 是否显示重试按钮
   */
  static handleAndShow(error, context = {}, showRetry = false) {
    const errorInfo = this.handle(error, context);
    this.showError(errorInfo, showRetry);
    this.logError(error, context);
  }
}

/**
 * 快捷错误处理函数
 * @param {Error|Object} error - 错误对象
 * @param {Object} context - 错误上下文
 * @param {boolean} showRetry - 是否显示重试按钮
 */
export function handleError(error, context = {}, showRetry = false) {
  ErrorHandler.handleAndShow(error, context, showRetry);
}
