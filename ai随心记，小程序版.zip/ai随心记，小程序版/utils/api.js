// API 调用封装模块

/**
 * 调用云函数
 * @param {string} name - 云函数名称
 * @param {Object} data - 传递给云函数的数据
 * @returns {Promise<Object>} 云函数返回结果
 */
export async function callCloudFunction(name, data) {
  try {
    console.log(`[API] 调用云函数: ${name}`, data);
    
    const res = await uniCloud.callFunction({
      name,
      data
    });
    
    console.log(`[API] 云函数返回:`, res);
    
    if (res.result && res.result.ok) {
      return {
        success: true,
        data: res.result
      };
    } else {
      console.error(`[API] 云函数执行失败:`, res.result);
      return {
        success: false,
        error: res.result?.error || 'CLOUD_FUNCTION_ERROR',
        message: res.result?.message || '云函数调用失败'
      };
    }
  } catch (err) {
    console.error(`[API] 云函数调用异常:`, err);
    return {
      success: false,
      error: 'CLOUD_FUNCTION_ERROR',
      message: err.message || '云函数调用异常'
    };
  }
}

/**
 * 生成游记
 * @param {Object} options - 生成选项
 * @param {string} options.address - 地点信息
 * @param {Array<string>} options.imageUrls - 图片 URL 数组
 * @param {string} options.template - 模板 ID
 * @param {string} options.feedbackText - 用户反馈（可选）
 * @param {string} options.apiKey - API Key
 * @param {string} options.model - AI 模型
 * @param {string} options.baseUrl - API 地址
 * @returns {Promise<Object>} 生成结果
 */
export async function generateNote(options) {
  const {
    address,
    imageUrls = [],
    template = 'literary',
    feedbackText = '',
    apiKey,
    model,
    baseUrl
  } = options;
  
  return await callCloudFunction('generate-note', {
    address,
    imageUrls,
    template,
    feedbackText,
    apiKey,
    model,
    baseUrl
  });
}

/**
 * 同步游记到云端
 * @param {Array<Object>} notes - 游记列表
 * @returns {Promise<Object>} 同步结果
 */
export async function syncNotes(notes) {
  return await callCloudFunction('sync-notes', {
    action: 'upload',
    notes
  });
}

/**
 * 从云端下载游记
 * @returns {Promise<Object>} 下载结果
 */
export async function downloadNotes() {
  return await callCloudFunction('sync-notes', {
    action: 'download'
  });
}

/**
 * 合并本地和云端游记
 * @param {Array<Object>} localNotes - 本地游记列表
 * @returns {Promise<Object>} 合并结果
 */
export async function mergeNotes(localNotes) {
  return await callCloudFunction('sync-notes', {
    action: 'merge',
    notes: localNotes
  });
}
