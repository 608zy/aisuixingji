// 同步服务
import { HistoryManager } from './history-manager.js'

/**
 * 同步服务类
 * 负责协调本地和云端数据的同步
 */
export class SyncService {
  /**
   * 执行完整同步流程
   * @returns {Promise<Object>} 同步结果
   */
  static async performFullSync() {
    try {
      console.log('[SyncService] 开始完整同步');
      
      uni.showLoading({ title: '正在同步...' });
      
      // 获取本地游记
      const localNotes = HistoryManager.getLocalHistory();
      
      // 调用云函数合并数据
      const res = await uniCloud.callFunction({
        name: 'sync-notes',
        data: {
          action: 'merge',
          notes: localNotes
        }
      });
      
      if (res.result && res.result.ok) {
        // 保存合并后的数据到本地
        const mergedNotes = res.result.data;
        await HistoryManager.mergeNotes(mergedNotes);
        
        uni.hideLoading();
        uni.showToast({
          title: '同步成功',
          icon: 'success'
        });
        
        console.log('[SyncService] 同步完成，总数:', mergedNotes.length);
        
        return {
          success: true,
          count: mergedNotes.length
        };
      } else {
        throw new Error(res.result?.message || '同步失败');
      }
    } catch (error) {
      console.error('[SyncService] 同步失败:', error);
      
      uni.hideLoading();
      uni.showToast({
        title: '同步失败: ' + error.message,
        icon: 'none'
      });
      
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * 上传本地未同步的游记
   * @returns {Promise<Object>} 上传结果
   */
  static async uploadLocalNotes() {
    try {
      console.log('[SyncService] 上传本地未同步的游记');
      
      // 获取未同步的游记
      const localNotes = HistoryManager.getLocalHistory();
      const unsyncedNotes = localNotes.filter(note => !note.synced);
      
      if (unsyncedNotes.length === 0) {
        console.log('[SyncService] 没有需要上传的游记');
        return {
          success: true,
          count: 0
        };
      }
      
      console.log('[SyncService] 需要上传的游记数量:', unsyncedNotes.length);
      
      // 调用云函数上传
      const res = await uniCloud.callFunction({
        name: 'sync-notes',
        data: {
          action: 'upload',
          notes: unsyncedNotes
        }
      });
      
      if (res.result && res.result.ok) {
        // 标记为已同步
        for (const note of unsyncedNotes) {
          await HistoryManager.markAsSynced(note.id);
        }
        
        console.log('[SyncService] 上传完成，数量:', res.result.count);
        
        return {
          success: true,
          count: res.result.count
        };
      } else {
        throw new Error(res.result?.message || '上传失败');
      }
    } catch (error) {
      console.error('[SyncService] 上传失败:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * 下载云端游记
   * @returns {Promise<Object>} 下载结果
   */
  static async downloadCloudNotes() {
    try {
      console.log('[SyncService] 下载云端游记');
      
      // 调用云函数下载
      const res = await uniCloud.callFunction({
        name: 'sync-notes',
        data: {
          action: 'download'
        }
      });
      
      if (res.result && res.result.ok) {
        const cloudNotes = res.result.data;
        
        console.log('[SyncService] 下载完成，数量:', cloudNotes.length);
        
        return {
          success: true,
          notes: cloudNotes,
          count: cloudNotes.length
        };
      } else {
        throw new Error(res.result?.message || '下载失败');
      }
    } catch (error) {
      console.error('[SyncService] 下载失败:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * 检查同步状态
   * @returns {Object} 同步状态信息
   */
  static checkSyncStatus() {
    const unsyncedCount = HistoryManager.getUnsyncedCount();
    const totalCount = HistoryManager.getLocalHistory().length;
    
    return {
      total: totalCount,
      unsynced: unsyncedCount,
      synced: totalCount - unsyncedCount,
      needSync: unsyncedCount > 0
    };
  }
  
  /**
   * 自动同步（静默）
   * 在后台自动上传未同步的游记，不显示提示
   * @returns {Promise<Object>} 同步结果
   */
  static async autoSync() {
    try {
      console.log('[SyncService] 执行自动同步');
      
      const status = this.checkSyncStatus();
      
      if (!status.needSync) {
        console.log('[SyncService] 无需同步');
        return { success: true, count: 0 };
      }
      
      // 静默上传
      return await this.uploadLocalNotes();
    } catch (error) {
      console.error('[SyncService] 自动同步失败:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
}

/**
 * 快捷同步函数
 * @returns {Promise<Object>} 同步结果
 */
export async function syncNow() {
  return await SyncService.performFullSync();
}
